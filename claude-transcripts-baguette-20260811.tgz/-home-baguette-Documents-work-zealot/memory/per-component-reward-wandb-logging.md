---
name: per-component-reward-wandb-logging
description: How per-component reward + termination-cause logging flows from the nexus env to W&B (the [rb] line + sidecar).
metadata:
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

PER-COMPONENT REWARD + TERMINATION LOGGING 2026-06-15 (user: "could we plot all reward and termination").
Plumbing, end to end:
- biped_env_nexus.rs: `pub const REWARD_COMP_NAMES: [&str; 24]` + `pub const NUM_REWARD_COMPS=24` +
  `pub struct RewardLog { comps:[f32;24], illegal, fell, timeout, samples }`. Indices 0–19 mirror
  `RewardBreakdown`'s live terms (track_lin_vel … feet_distance), 20=torque_leg 21=torque_ankle
  22=self_coll 23=termination. Env struct gained accumulators `rlog_comps:[f64;24]`, `rlog_steps`,
  `rlog_illegal/fell/timeout`. The par-compute closure fills a per-env `comps` from `rb` (kept the
  breakdown instead of `.total()`) + the env-side torque/self-coll penalties (as NEGATIVE values) +
  termination. Serial-commit loop sums comps and tallies term causes (illegal > fell > timeout,
  mutually exclusive). `take_reward_log()` drains → per-step means + episode-total term counts.
- biped_train_gpu.rs: every 10 iters (same cadence as the table) prints
  `[rb] iter <it> name=val … term_illegal=N term_fell=N term_timeout=N samples=N`.
- wandb_logger.py: `parse_rb()` namespaces reward terms under `reward/`, term counts under `term/`;
  main loop buffers per-step and flushes on step-advance so the table row + [rb] row merge into ONE
  W&B history row (steps must be non-decreasing). Run: `python3 scripts/wandb_logger.py <log> <name>`.
HOST-SIDE ONLY — no cubin rebuild. Build: `BIPED_CUDA=1 cargo build --release --example biped_train_gpu
--features "gpu biped_gpu cuda_backend"`. Compiles clean (only dead-code warnings).
NOTE: v7 (running old binary, /tmp/train_v7.log) predates this and emits NO [rb] lines — needs a fresh
run. v7 plateaued ~iter 1420: reward −3.79, falls 6362, curriculum 1.0, not improving (the stand-still
optimum again). The natural next run pairs this logging with the velocity-tracking reward rebalance.
See [[prefers-natural-motion]] and [[fragile-ankle-hardware]].

---
name: perf-work-must-preserve-behaviour
description: "Don't propose changing learning semantics (PPO/symmetry/reward) as a performance optimization — perf work must be behaviour-preserving and verified bit-exact."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 81953d33-c9bf-4579-b61e-bc2320be88e4
  modified: 2026-08-08T08:02:55.680Z
---

Haixuan, 2026-08-08, on my suggesting a switch from mirror AUGMENTATION to
mirror LOSS to save ~6-8%: *"You mean changing ppo logic that's crazy."*

**Why:** a symmetry method is not overhead — the batch doubling IS the method
doing its job. Costing it on a wall-clock scoreboard treats a
learning-algorithm decision as an optimization, and the downside (a worse
policy after a 50k-iteration run) is invisible to every benchmark I can run in
a session.

**How to apply:** performance work is behaviour-preserving by definition.
Everything that landed in the 6.2 -> 1.0 s/iter run was verified identical to
the path it replaced (`BIPED_VERIFY_RESET`, `BIPED_VERIFY_STAGE`, matched fall
counts). If a candidate change alters what the optimizer sees — symmetry
method, reward terms, normalization semantics, substep cadence — it is a
TRAINING experiment, not an optimization. Say so, and evaluate it on policy
quality (gait metrics, MuJoCo transfer), never on s/iter.

Corollary that would have caught this earlier: check the reference first.
WBC-AGILE sets `use_data_augmentation=True, use_mirror_loss=False` on both its
G1 and T1 configs, and every zealot policy that ever walked used augmentation
([[walking-gait-attempts]]). Diverging from the stack zealot deliberately
mirrors needs a reason stronger than throughput.

NOTE `NEXUS_SUBSTEP_REFRESH=0` ([[zealot-substep-refresh-regression]]) is the
one behaviour-changing default I did flip — justified because it reversed an
accidental regression against v28, not because it was faster. It still carries
a train/eval-consistency caveat.

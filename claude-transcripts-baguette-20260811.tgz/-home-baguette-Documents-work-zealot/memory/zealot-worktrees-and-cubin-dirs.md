---
name: zealot-worktrees-and-cubin-dirs
description: "zealot-pr4/-unified are git WORKTREES of ~/Documents/work/zealot (pr4 now detached at e8d3aa3; main tree is on master); ~/nexus_ptx is canonical again (master cubins consolidated 2026-08-05, pr4/pr4fix dirs deleted); stale-cubin symptom = CUDA_ERROR_NOT_FOUND at load_function."
metadata: 
  node_type: memory
  type: project
  originSessionId: b905e023-5d9a-49af-86a2-f055e9b8f2f6
  modified: 2026-08-05T15:27:18.052Z
---

Tree layout (discovered 2026-08-05): `zealot-pr4` and `zealot-unified` are git
**worktrees** of the main repo `~/Documents/work/zealot` (`.git` is a file
pointer). The v28 run (50k iters, `train_fixed_v28.log`) was launched from
zealot-pr4 while it had **master** checked out; master had evolved 106 commits
past `feat/contact-force-sensor` and superseded its contact-sense work (its
own force_rate / action_rate_rate / touchdown_vz comps; com_centering
removed; 31→now 32 comps with [[chest-stability-reward-and-waist-gains]]).

Since 2026-08-05: **main tree = master** (train from there; overnight scripts
already `cd ~/Documents/work/zealot`). zealot-pr4 is DETACHED at e8d3aa3 so
master stays free — don't re-checkout master there. The live v28 process keeps
running from pr4's old binary (backed up to
`~/overnight/biped_train_gpu.live_v28_backup` — its inode was the only copy).

**CUBINS (consolidated 2026-08-05):** `~/nexus_ptx` is canonical again — it
now holds the master-compatible cubins (mprops hash 6570286a…, ex-pr4fix
Jul 27 build); the stale feat-era cubins are kept as
`*.cubin.feat_jul21.bak` / `*.cubin.feat_jul15.bak` beside them. The
`nexus_ptx_pr4` / `nexus_ptx_pr4fix` dirs are DELETED. (deleted 2026-08-05:
nexus_ptx_unified + nexus_ptx_ctl — unified branch merged, its WIP committed as b1ddea1.)
CUBIN TRAP: a binary built against a cubin whose kernel hashes don't match its
shader-crate source fails at startup with `[khal-cuda load_function FAIL]
…_cuda_entry_… CUDA_ERROR_NOT_FOUND`. Setting the CUDA_OXIDE_SHADERS_PTX_*
env vars to a different path DOES retrigger the embed on rebuild.
Related: [[native-cuda-build-pinning]], [[rapier-vendored-tree-restored]].

UPDATE 2026-08-05 (portability sweep before user left the box): everything
pushed — zealot master REBASED onto origin (chest commit now 0f3e968, examples
purge c890d39; 51→8 examples: 5 keepers + 3 web demos from the other machine);
khal/vortx/nexus branches pushed (nexus lives at haixuanTao/nexus — nexus-cuda
AND nexus-rl repos are archived/dead); vendored parry → haixuanTao/parry-vendored,
naga-fixed → haixuanTao/naga-fixed@vendored-20260805. scripts/train.sh +
scripts/build_cubins.sh + scripts/render_g1.sh committed ($HOME-relative).
cutile-rs needs NO fork (pristine NVlabs v0.2.0; its zealot bench salvaged to
tools/cutile_zealot_shapes_bench.rs).
RESOLVED (was wrongly blamed on "another machine"): the new nexus3d APIs
(scatter_motor_targets_gpu / step_encoded / links_workspace_buffer) live in
fork branch **feat/browser-web-demo** — the 4-branch grep had missed it. The
nexus checkout is now ON that branch and zealot master compiles here. BUT:
(1) browser-web-demo DIVERGED from fix/mb-solver-consistency (the training-
validated solver) — they need merging before the next training cutover;
(2) FIXED: cherry-picked the drop-patch commit onto feat/browser-web-demo
(a8528a6, pushed) — cuda-device now comes from git upstream on that branch
too, and the cuda-oxide-upstreaming clone is deleted for good; (3) RESOLVED: the branch's CUDA shader
rot (chain_buf &mut [u32;264] vs SmemBuf) is fixed on the branch (d2451e0,
generic MaybeIndexUnchecked — lu.rs pattern) and ~/nexus_ptx now holds
browser-web-demo cubins (solver-era kept as *.solverbranch.bak). CUBIN BACKEND
PAIRING MATRIX (both verified 2026-08-05): host-target interception (what
scripts/build_cubins.sh now does, ex-full_unified_chain) pairs with the
khal-pinned upstream rev 62472763; the old device-target route pairs with
a5f4062f (reconcile-translators). CROSSING them fails (upstream pin dies in
atomics lowering under device-target; a5f4062f dies in module verification
under host-interception). Backend auto-builds cached at
~/.cache/zealot/cuda-oxide. ONNX exporter = scripts/export_policy_onnx.py
(scripts/export_onnx.py deleted). Master now RUNS CUDA end-to-end on this box with bare defaults. Tag `local-buildable-20260805`
(= 4576100) still marks the solver-branch-era state; the working cutile
trainer binary sits in zealot/target/release/examples/biped_train_gpu.
Authoring pattern: commits appear on origin as lowercase "haixuantao" and are
PULLED here (pr4 reflog showed morning pull chains) — training runs here.

NEXUS CONSOLIDATION 2026-08-05: one clone, one name — `~/Documents/work/nexus`
(standalone clone of haixuanTao/nexus, branch fix/mb-solver-consistency
@ae5823e; zealot Cargo.toml + scripts now say `../nexus`). Deleted:
nexus-cuda, nexus-merge, nexus-cuda-merge (its uncommitted joint-cfm solver
WIP rescued to fork branch `wip/joint-cfm-refactor`), nexus-pr4, and the
nexus-rl symlink — all HEADs verified present in the fork first.
**WORKTREE TRAP (hit once):** the *-unified dirs were `git worktree`s — old
`nexus-unified`'s parent was nexus-cuda, and deleting the parent orphaned it
(repaired via re-init + plumbing; tree was clean+pushed so nothing lost).
`khal-unified` and `vortx-unified` are worktrees of `~/Documents/work/khal`
and `~/Documents/work/vortx` — NEVER delete those parent dirs while the
unified trees live.

SCRIPT PRUNE 2026-08-05 (9bdd7ff): the one-time investigation probes cited in
older memories (critic_divergence.py, motor_step_compare.py, sim2sim/engine
divergence, foot_rotation_xval, foot_tip_stability_newton, render_foot_tip,
mujoco_passive_stand, posture_metrics, cross_engine_eval, render_g1_mujoco,
render_biped_nexus_native, render_sim2sim_mujoco, sim2sim_bench,
cutile_zealot_shapes_bench.rs) are DELETED from the tree — recover with
`git log -S <name>`. scripts/ = 18 keepers: launchers, exporter, wandb
sidecar, validators (sim2sim_g1_mujoco/xval/genesis/isaac), render pipeline,
generators (convert/pull_agile/bake_g1_*). Demo assets come from HF
(haixuantao/zealot-g1-locomotion assets/) via scripts/fetch_demo_assets.sh.

MACOS/WEBGPU READINESS 2026-08-05 (bb5f74e): scripts/train.sh auto-detects
backend (nvidia-smi → CUDA+cutile, else WebGPU/Metal). GOTCHA FIXED: the
grad-clip reduce bound sqn column views at 4-byte offsets — fine on CUDA,
REJECTED by WebGPU/Vulkan (256) and Metal (32) bind-group alignment; fixed
zealot-side with 64-float (256 B) row slots (vortx Tensor storage is
ROW-major despite the column-major doc comment — columns_mut(k,1) offset is
4k regardless of nrows). Underlying vortx limitation stands: any narrow
tensor VIEW at an unaligned element offset panics on non-CUDA backends.
docs/train-on-macos.md carries the pinned stack table (zealot master,
nexus feat/browser-web-demo@d2451e0, khal/unified@c6175be,
vortx/unified@1495fe4, rapier world, parry-vendored, naga-fixed,
cutile-rs v0.2.0 — the cutile PATH DEP must exist on disk even on macOS).

VIDEO ARCHIVE + GDRIVE (2026-08-07): eval videos live in ~/zealot-archive/
(2026-08_v28-evals/{cross-engine,snapshots,final-sweep,tremor-study,
diagnostics} + README.md with all measured results). Synced to Google Drive
folder `zealot-archive` via ~/zealot-archive/sync-to-gdrive.sh (rclone
v1.75 at ~/.local/bin, remote `gdrive:`, already authed — re-runs are
incremental). NOTE eval videos are otherwise written to the SESSION
SCRATCHPAD under /tmp and die on reboot — copy anything worth keeping into
~/zealot-archive. Not yet archived: ~/lerobot-legged-zoo/videos (v5/v9/v13/
v16 lineage) and ~/tmp_eval (early G1). LESSON: I deleted the repo's
overnight/ during the 08-06 cleanup, which held 6 untracked July-16 videos
(stand/velocity/pushrecovery ±mesh) — check dirs for media before rm -rf.

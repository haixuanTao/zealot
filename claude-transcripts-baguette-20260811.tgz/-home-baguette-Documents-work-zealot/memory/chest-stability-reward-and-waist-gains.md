---
name: chest-stability-reward-and-waist-gains
description: "Chest (torso_link above waist) was invisible to all stability rewards; added chest_ang_vel term (BIPED_CHEST_ANGVEL_W, default 0) + aligned g1_29dof held gains to the deploy table (waist 300/5). g1_29dof_agile always had 300/5 — the live runs were never gain-mismatched."
metadata: 
  node_type: memory
  type: project
  originSessionId: b905e023-5d9a-49af-86a2-f055e9b8f2f6
  modified: 2026-08-05T15:27:05.690Z
---

On the 29-DOF G1 every "stability" reward term (upright, body_ang_vel,
base_height) reads the PELVIS (link 0); the chest (`torso_link`, 3 bodies up
the PD-held waist chain) was invisible to the reward — the policy was never
told the torso matters, and an underdamped waist turns the chest into a
resonator near step cadence.

LANDED ON MASTER 2026-08-05 as e8d3aa3 (chest_ang_vel = comp 31 of master's
32-comp stack; feat-branch original preserved as 23753de). The main zealot
tree is now checked out on master — train from there. Original notes:

Done 2026-08-05 (branch feat/contact-force-sensor, uncommitted):
- **chest_ang_vel reward** (biped_env_nexus.rs): env-side penalty
  `w·(ωx²+ωy²)·dt` on the chest link's roll/pitch rate (finite-diff quat, yaw
  excluded so turning isn't taxed). `BIPED_CHEST_ANGVEL_W`, DEFAULT 0 (off).
  Comp #29 `chest_ang_vel` in the `[rb]` line. At w=0.05 an untrained policy
  logs ~-0.10/step (similar scale to body_ang_vel) — start ~0.02-0.05.
  `LinkIndices.chest_link` = MJCF body "torso_link", falls back to 0 on
  legs-only models.
- **Gain alignment**: `unitree_g1_29dof` held_joints were kp100/kd2 waist +
  40/1 arms ("holding gains"); now the deploy/AGILE table (waist 300/5,
  shoulder_pitch 90/2, shoulder_roll+elbow 60/1, shoulder_yaw 20/0.4,
  wrist 4/0.2) — identical to `unitree_g1_29dof_agile`.

IMPORTANT correction to the analysis that motivated this:
`g1_29dof_agile` (used by ALL the agile_fullbody runs incl. the live Aug-5
run) ALWAYS had waist 300/5 — the train/deploy mismatch and the ~1.5-2 Hz
resonance estimate applied only to the plain `g1_29dof` spec. With 300/5 the
waist natural freq is ~√3 higher (above step cadence) but still underdamped;
the chest_ang_vel term is the remaining lever against chest jitter.

Related: [[reward-alignment-wbc-lerobot]], [[per-component-reward-wandb-logging]].

STANCE-WIDTH FINDING (2026-08-07, parked by user choice): v28-44k walks with
feet 0.347 m apart vs 0.129 m hip separation (legs splay ~11° from vertical;
measured via the harness STANCE trace). The feet_distance reward refs 0.2 m
but at weight -1.0 the 15 cm overshoot costs only ~0.003/step — width is the
policy's cheap answer to 0.5 m/s push DR. Queued candidate for a future run:
W_FEET_DISTANCE -1 -> -5 (keeps ref 0.2); watch falls for the
stability-vs-stance trade. NOT applied to v29 (user kept the run clean).

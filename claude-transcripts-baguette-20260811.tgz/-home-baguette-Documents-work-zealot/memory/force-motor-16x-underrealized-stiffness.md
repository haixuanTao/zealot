---
name: force-motor-16x-underrealized-stiffness
description: "The force-based motor under-realized kp ~16x (not unstable) — WBC gains were AccelerationBased-calibrated. Fix is host-side kp×16/kd×4; likely the real walking blocker (mushy legs can't hold single-support)."
metadata: 
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

DISCOVERED 2026-06-20 (via the passive_stand probe, prompted by a Mac/Metal contact investigation):

**The force-based motor (the sim-to-real-faithful default) under-realizes commanded stiffness by ~16×.**
passive_stand (zero action, PD holds nominal pose) on baguette/CUDA:
- ForceBased default (kp×1): holds ~0.4s then TIPS, body sinks to ~−0.66 (caught by foot contact, NOT a
  free-fall — contact works). Gain sweep: kp×2,×4 and kd×3 all still collapse. kp×8 partial. **kp×16,kd×4 =
  ROCK-SOLID 0.719 forever; kp×32 also solid (not oscillating).** Monotonic + stable at high gain ⇒
  UNDER-REALIZATION, not instability.
- AccelerationBased (kp×1): rock-solid 0.719 (it's inertia-decoupled, so kp realizes ~16× the torque-PD stiffness).

**Why:** the WBC kp/kd (anklex40 ankle20 hipy/knee60, kd 1.5–4) were calibrated for AccelerationBased
(q̈ = kp·err, inertia-decoupled). As REAL torque gains in ForceBased (q̈ = τ/M, physically correct), they're
too soft — legs sag under gravity until the CoM tips. SPD/implicit integration is NOT the fix (corrections ∝dt²
are negligible at sim_dt=1/200; ruled out before any cubin rebuild). It's purely a stiffness deficit.

**Fix (host-side, no cubin rebuild):** force-based motor defaults to kp×16, kd×4 in biped_env_nexus.rs
(`set_motor_position`, gated on `matches!(motor_model, ForceBased)`; AccelerationBased stays ×1; override via
BIPED_KP_SCALE/BIPED_KD_SCALE). REALISTIC because the ±effort clamp still caps torque at the fragile limit
(15 N·m ankle) — a stiff servo that saturates at its current limit, exactly like real hardware. Holding torque
= gravity regardless of kp, so stiffer only kills the sag, doesn't burn more torque. passive_stand now holds
0.719 by default.

**Why it matters:** every walking run v37–v45 trained on the MUSHY (kp×1) motor — strong candidate for WHY the
robot never lifted a foot across 6 reward structures (air_time always exactly 0): legs too soft to hold
single-support, so lifting → buckle → fall, so the policy correctly never lifted (only the sub-threshold
slide-shuffle, which doesn't transfer — MuJoCo gave lateral drift, fwd ~0). v46 = first retrain on the stiff
motor (from scratch, gait clock + CoM-centering). WATCH air_time: >0 ⇒ motor was the blocker. See
[[nexus-freefall-dynamics-bug]] (the original AccelerationBased fix + "RETRAIN to confirm walking" note we'd
never acted on), [[cuda-backend-feature-required-for-speed]], [[fragile-ankle-hardware]].

Also settled: Mac/Metal passive_stand free-falls to −1411 = Metal contact produces ZERO force (broken);
CUDA contact works (catches at −0.66, holds with accel motor). Training belongs on the CUDA boxes (where it is).

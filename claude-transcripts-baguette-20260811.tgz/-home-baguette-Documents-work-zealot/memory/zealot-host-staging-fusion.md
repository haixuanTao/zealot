---
name: zealot-host-staging-fusion
description: The non-physics 65% of an iteration was dominated by three-pass host staging (normalize -> Vec-per-sample -> DMatrix -> transpose); fusing it took 1.5 -> 1.1 s/iter.
metadata:
  type: project
---

Found 2026-08-08 by profiling the non-physics part of an iteration
([[zealot-vs-agile-benchmark]]). `BIPED_ROLL_PROF=1` emits a `[prof-roll]`
split (norm / forward / sample / step / post); `BIPED_RESET_PROF=1` splits reset
into prepare / scatter / finish. Both are permanent, env-gated.

**The recurring bug shape**: staging a batch for vortx walked the data THREE
times and allocated twice —
`batch.par_iter().map(|s| norm.normalize(&s.obs))` (a `Vec` per sample), then
`DMatrix::from_fn` (column-major), then the `transpose()` hidden inside
`Tensor::matrix_from_na`. ~620 MB of host allocation for the actor obs alone,
because mirror augmentation doubles the batch to 196k samples.

Fix: `Normalizer::affine()` exposes the per-feature `(mean, 1/σ)`, so ONE
parallel pass over ROWS writes vortx's row-major layout directly with
sequential stores. Applied in two places:

| site | before | after |
|---|---|---|
| PPO update staging (`stage_rows`) | 0.36 s | 0.11 s |
| `GpuPolicy::forward` per step | 0.18 s | 0.04 s |

Also: the per-step motor upload pushed the ENTIRE `links_static` mirror (26
links x 4096 envs, each a struct with a full `GenericJoint` + mass properties)
to change 12 floats per env — 2.6 ms/step. Replaced by nexus
`scatter_motor_targets` (a `[12 x n]` upload + kernel) → 1.8 ms, then caching
the scatter's shader + 4 constant buffers (rebuilt EVERY call, same anti-pattern
as the reset params allocation) → **0.1 ms**. `held_dirty` still forces the full
flush on steps where arm playback restaged HELD joints — the scatter only
rewrites actuated entries.

Commits: zealot `b16c9f4`, `8326313`; nexus `81fb125`. All host-side — no cubin
rebuild.

**Still on the table** (deliberately not done): making the rollout obs fully
device-resident so the update needs no staging. Worth ~0.11 s of a 1.1 s
iteration now (was 0.36 s when first ranked). Needs (a) a strided scatter kernel
— vortx's batch is row-major `[dim x total]` so a step's block isn't contiguous,
(b) reordering the host batch from env-major (`c = e*T + t`) to step-major in
lockstep across actions/logp/adv/ret/values, and (c) a mirror gather kernel,
since mirrored samples were never forwarded. PPO-correctness sensitive.

Left host-side ON PURPOSE: the 24-term reward (2.0 ms/step) — kernelizing means
a cubin rebuild every time a reward weight changes.


## Traced 8192 (2026-08-08) — two corrections worth keeping

1. **`[prof-upd] encode` is NOT host command recording.** Doubling the dispatch
   count (`BIPED_MINIBATCHES` 4 -> 8, same total work) moved it 0.24 -> 0.26s;
   host recording would have doubled. It is ~90% GPU execution — the host blocks
   on flushes inside that block, and `exec` reads 0.00 because the GPU is
   already drained by the final sync. There is no host-side fix for it.
2. **Nothing scales badly.** 4096 -> 8192 ratios: physics 1.86x, encode 1.85x,
   reset 1.5x, reward 1.47x, staging 2.09x; whole iteration 1.84x for 2x envs.

Staging fixes: row-block the transpose (16 rows/pass — one row per pass streamed
the ~200 MB working set once PER ROW, ~3 GB of traffic), then gather samples
into contiguous arenas so each is touched once instead of once per row-block.
Fills at 8192: obs 46->29ms, critic 28.8->24.7ms, actions 11.6->3.0ms.

**The arena is size-dependent** — a real win at 4096 (1.1 -> 1.0 s/iter),
NEUTRAL at 8192 where the gather pass costs what the fills save. It also adds
~500 MB transient (RSS 2.13 -> 2.65 GB at 8192). Kept because 4096 is the
production size.

Staging is now at the floor for a HOST-materialized batch: obs alone is 417 MB
at 8192 (mirror aug doubles `total` to 393k samples), so 0.17s = one scattered
read + one flat write + a 24ms upload. `BIPED_STAGE_PROF=1` splits fill vs
upload per tensor. Only device-residency goes lower.

Note for that work: mirror-normalized[r] = A_r * raw[sigma(r)] + B_r is an exact
affine on the RAW obs, so the mirrored half can be generated on device — but
deriving it from the already-normalized arena is only exact if the +/-5
normalize clamp never bites (UNVERIFIED). Doing it exactly means keeping raw obs
on device and normalizing there.


## Device-resident PPO batch — DONE (2026-08-08)

zealot `a91bd98` + vortx `gpu_ppo_stage_batch`. The rollout retains RAW obs on
device (step-blocked `[T][dim][n]`, one contiguous write per step) and the
update builds `[dim x total]` there: normalize + clamp + mirror augmentation in
one dispatch per tensor. Host does no normalize/transpose/arena/upload for obs.

Staging 0.09 -> 0.02s @4096, 0.17 -> 0.05s @8192. RSS 1.43 -> 1.17 GB and
2.65 -> 1.82 GB; VRAM +128/+224 MB for the raw buffers.

Why normalization must be IN the kernel: the mirror is defined on RAW obs
(`normalize o mirror`) and the +/-5 clamp is lossy — `BIPED_CLAMP_PROBE=1`
measured 1.7M clamped values early in a run, so a mirror derived from
normalized values is wrong for every saturated feature.

The mirror reaches the kernel as a verified signed-permutation table
(`mirror_table()` probes `mirror_obs`/`mirror_critic` with basis vectors and
asserts linearity), so it cannot drift from the host definition.

**Two traps hit while building it:**
1. First version was SLOWER than the host path — the output tensors were
   allocated per iteration with `Tensor::matrix(.., &vec![0f32; n], ..)`, i.e.
   a host zero-fill plus a full upload of exactly the bytes being eliminated.
   Persistent + `matrix_uninit` fixed it. Same per-call-allocation shape as the
   reset params and motor-scatter bundles.
2. Fall counts do NOT validate a column mapping. `BIPED_VERIFY_STAGE=1`
   compares the device tensor element-for-element against the host formula over
   BOTH halves (reports maxdiff 0.000e0). Use it after any batch-layout change.

## Remaining host transfer, N=8192 (~700 MB/iter, ~35ms)

obs normalized->actor input 208 MB; **obs RAW->batch 208 MB (DUPLICATE)**;
critic normalized 50 MB; **critic RAW 50 MB (DUPLICATE)**; slurp_poses readback
164 MB; motor targets 9 MB; means/values readback 10 MB.

The duplicate ~258 MB/iter is removable: add `raw_offset` to `PpoStageParams`
so the SAME kernel produces the per-step policy input from the raw buffer
(`total=n, horizon=1, mirror_half=0, raw_offset=t*dim*n`); then only raw is
uploaded and forward's host normalize pass goes away too (~25-30ms). NOT DONE.

The 164 MB pose readback is structural — obs/reward are host-side by choice.

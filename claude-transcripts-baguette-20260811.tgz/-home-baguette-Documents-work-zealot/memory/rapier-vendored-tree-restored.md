---
name: rapier-vendored-tree-restored
description: "~/Documents/work/rapier (vendored, required by zealot+nexus-cuda [patch]) was deleted ~Aug 2026; restored as a git clone of haixuanTao/rapier branch `world` (rapier3d 0.32.0 + glamx 0.2, urdf 0.13.0 — matches Cargo.lock). Possible uncommitted mods in the old copy are lost."
metadata: 
  node_type: memory
  type: project
  originSessionId: b905e023-5d9a-49af-86a2-f055e9b8f2f6
  modified: 2026-08-05T13:30:16.612Z
---

The vendored `~/Documents/work/rapier` tree (NOT a git repo, rsync'd from the
Mac per docs/vast-cuda-build-log.md) disappeared from disk between 2026-07-25
(last successful trainer build) and 2026-08-05, breaking `cargo build` in both
zealot and nexus-cuda (`[patch.crates-io]` paths `../rapier/crates/*`).

**Restored 2026-08-05** as a git clone of `haixuanTao/rapier` branch **`world`**
(the branch recorded in zealot `docs/train-on-macos.md:32`): workspace version
0.32.0, glamx 0.2, rapier3d-urdf/meshloader 0.13.0 — exact match to zealot's
Cargo.lock (path deps, no checksum). Note rapier 0.32 IS the glam(x) migration
release, so glamx types are upstream, not a fork oddity.

**Caveat:** if the old vendored copy carried uncommitted local mods (the
vast-cuda log says the rsync included some), they are lost. Trainer rebuild +
2 smoke runs (g1_29dof_agile and g1_29dof, 256 envs) pass; watch the next full
training run for behavior drift attributable to CPU-side scene build.

`~/Documents/work/parry` is still the ORIGINAL vendored copy (heavily modified
vs upstream v0.26.1 — do NOT "restore" it from a tag; no known git source).

Build reminder (see [[native-cuda-build-pinning]]): always export
CUDA_OXIDE_SHADERS_PTX_NEXUS_RBD_SHADERS3D + CUDA_OXIDE_SHADERS_PTX_VORTX_SHADERS
(cubins in ~/nexus_ptx) during `cargo build`, else khal-builder tries a
cargo-cuda rebuild ("Codegen backend not found") or silently drops the cubin.

---
name: nexus-contact-model-realism
description: "nexus foot-ground contact model reality, the foot-box footprint bug fix, and which contact DR knobs are silently dead"
metadata: 
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

Investigated 2026-06-17 because the biped stands rock-solid in nexus but falls in ~1.3 s in MuJoCo (brace-and-stagger), and the foot config looked unrealistic.

**nexus contact model (the multibody path the biped uses):**
- Sliding Coulomb friction only — 1 normal + 2 tangents, box clamp (±μ·fₙ per tangent). No torsional/rolling friction. (MuJoCo here is also slide-only: default condim=3, so this gap is small.)
- Friction is a SINGLE μ stored per-multibody (extracted from collider material into MultibodyInfo). NOT per-collider/per-foot, no static/dynamic split, no per-pair combine → per-foot & stick-slip friction are ENGINE-BLOCKED.
- **Restitution DR is DEAD**: the multibody contact path has no restitution term (only the free-body path, which hardcodes e=0). `DrParams.restitution` is a no-op.
- **Contact-stiffness DR — was DEAD, now REVIVED (2026-06-17, v21)**: `contact_natural_frequency`/`contact_damping_ratio` were hardcoded 30/5 in gpu_mb_init_contact_constraints. The old "binding bug" was just that the kernel never got a SimParams binding (only dt). Fix: added `all_params: &[SimParams]` at descriptor set 1 binding 4 (mirrors the working free-body solver), read the two stiffness fields via `all_params.at(batch_id)`, kept dt from dt_uniform (so 30/5 is bit-identical to old). Threaded `sim_params` tensor through MultibodySolverArgs (TWO construction sites: pipeline.rs:1001 AND solver.rs:313 substep loop). Rebuilt cubin (build_nexus_cubin_libnvvm.sh, EMBED HASH MATCH). Verified stable at fixed 30/5 (BIPED_CONTACT_FREQ=30 BIPED_CONTACT_DAMP=5, torso holds 0.72–0.77, no NaN). DR now live: freq 10–50 Hz, ζ 2–8 — the analog of MuJoCo solref randomization. .call() wrapper orders args by (set,binding), so the new binding is appended last in the dispatch.
- Joint dry friction (MJCF frictionloss=0.1) IS modeled — seeded via set_dof_frictionloss. Soft contact via ERP/CFM. nexus narrow-phase supports Ball/Capsule/Cuboid; ONE collider per body (batch layout `colliders_per_batch=mjcf.len()+1` requires it).
- Physics contact is REAL foot-box-vs-ground-cuboid. The "synthesized via foot Z < threshold" is only reward/obs-side contact DETECTION (nexus doesn't expose narrow-phase pairs to host).

**Foot-box footprint bug (FIXED in biped_env_nexus.rs build_env_scene):** the single foot cuboid spanned the capsule bounds INCLUDING radius → footprint ~0.094×0.135 m vs the real sole ~0.064×0.105 m (~+47% area) → unrealistically large/stable support polygon the policy braced on. Fix: span capsule CENTERLINES; add radius back only on the sole-thickness axis (smallest-extent axis) to keep bottom-surface height. Both engines load the same robot.xml (MuJoCo keeps the 6 sole capsules rounded; nexus collapses to one box).

**Done host-side (v20 run):** foot footprint fix + friction range widened to 0.3–1.3 (slip regime, BIPED_FRICTION knob, per-template). v20 still learns to stand (harder/slower, as expected). See [[reward-alignment-wbc-lerobot]], [[render-path-valid-no-rust-walker]], [[nexus-freefall-dynamics-bug]].

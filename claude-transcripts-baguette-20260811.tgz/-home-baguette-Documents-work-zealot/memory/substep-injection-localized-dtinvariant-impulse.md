---
name: substep-injection-localized-dtinvariant-impulse
description: "The long-unlocalized substep energy injection (drift ∝ substeps) = the per-substep contact NORMAL IMPULSE is ~dt'-invariant (should be ∝dt'); the single-point foot converts the excess into unbalanced torque → spin → drift."
metadata: 
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

2026-06-23. The substep energy injection (drift ∝ solver substeps, "resists targeted
localization" per [[foot-slip-sim2real-gap]]) is finally pinned to ONE measurable,
provably-wrong quantity — enabled by the [[foot-pivot-root-cause-single-collider]]
single-point insight.

MEASUREMENT (no new probe needed — mb contacts are rebuilt fresh each substep with
impulse=0, so the end-of-step debug_contact_impulses N[link] value IS the LAST
substep's normal impulse). Loaded-foot per-substep NORMAL impulse vs substep count
(decim=4, capsule, v56 policy, iters=2/8/16 → dt'=2.5/0.625/0.3125 ms):
  iters   dt'        measured impulse    ∝dt' (correct) prediction
   2     2.5  ms        0.096               0.096
   8     0.625ms        0.086               0.024   (should be it2/4)
  16     0.3125ms       0.072               0.012   (should be it2/8)
=> impulse is ~dt'-INVARIANT (−25% over an 8× dt' cut, vs the 8× drop a correct
impulse needs). So each substep delivers ~the SAME normal impulse regardless of dt';
total contact impulse over a control step ∝ substep count instead of being constant
(= m·g·control_dt). The contact over-pushes by ~N×.

WHY IT BECOMES DRIFT (unifies with single-point): the excess impulse is applied at a
SINGLE contact point offset ~5 cm from the COM (foot is one collider, tilts, one
corner loads). A multi-point patch would cancel the per-point normal torques; one
point can't, so the excess → net UNBALANCED torque → foot spins up ∝ substeps →
origin drifts (v_origin=ω·R, R≈5cm). Hence drift ∝ substeps. implicit_coriolis
(default TRUE) is NOT the cause — fresh jacobians per substep still show the scaling.

ROOT CONFIRMED (not warmstart — mb contacts have none; rebuilt fresh each substep).
contact_constraints.rs gpu_mb_init_contact_constraints:206:
  erp_inv_dt = ang_freq / (dt·ang_freq + 2·ζ),  ang_freq = contact_NF·2π (~188), ζ~5.
As dt'→0 this → ang_freq/(2ζ) = a CONSTANT. Numerically erp_inv_dt = 18.0 / 18.6 / 18.7
at dt' = 2.5 / 0.625 / 0.3125 ms — dt'-INVARIANT. So rhs_bias = erp_inv_dt·(dist+err)
(line 337) is a dt'-invariant velocity bias → dt'-invariant per-substep impulse. This is
classic BAUMGARTE position-correction ENERGY INJECTION: the bias velocity touches the
real velocity and isn't fully removed. The TGS-soft no-bias stabilization pass
(remove_solve_contact_no_bias, apply_substep step 10) is supposed to cancel it; the
residual leaks ∝ substeps. (The earlier ERP fix that swapped erp_inv_dt=inv_dt → this
damped form unlocked learning but left this residual.)

Production iters=2 is FINE (2 substeps → ~2× over-push, foot drift still ~MuJoCo 0.1);
the injection only bites at high substep counts.

FIX candidates (in priority):
(1) SPLIT-IMPULSE / pseudo-velocity for the position correction: apply the Baumgarte
    bias through a separate pseudo-velocity channel that corrects penetration but NEVER
    adds real kinetic energy (textbook fix). Or verify/repair the no-bias pass fully
    removes the bias velocity from dof_state.
(2) Multi-point contact patch (blocked by 1-collider assertion, see
    [[foot-pivot-root-cause-single-collider]]) so the excess can't become UNBALANCED
    torque — addresses the drift path, not the injection itself.
(3) Angular friction (condim=6, ANG_FRICTION_LEN=0.05, implemented) only shaved ~10-17%
    — fights the symptom (spin), not the dt'-invariant impulse source.

---
name: tier2-gpu-resident-rollout-not-worth-it
description: "Measured finding — GPU-resident rollout (Tier 2) is not worth building on the 5090; the policy round-trip is <5% of a step, physics is ~95%."
metadata: 
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

On the RTX 5090 + WebGPU box, the full-GPU rollout step (`rollout_e2e_bench`) is dominated by `env.step` (nexus physics), not the policy round-trip.

Measured split (control step):
- N=2048: forward 2.99 ms + sample 0.41 ms = **3.4 ms (4.6%)**, env.step **70.45 ms (95%)**, total 73.99 ms.
- N=256: forward 1.89 ms + sample 0.07 ms = **1.96 ms (3.6%)**, env.step 52.11 ms (96%).
- The per-step policy readback (R1, two `slow_read_vec`) is only **0.165 ms** at N=4096 — `slow_read_buffer` already pools its staging buffer, so readback is near-free here. GPU forward compute is ~1.2 ms.

**Why:** a proposed "Tier 2" plan (sample actions on GPU + a new nexus `scatter_motor_targets` shader to write motor targets into `links_static` on GPU, GPU-resident rollout buffers) was meant to remove the per-step CPU↔GPU policy round-trip. But that round-trip is <5% of the step, so the whole effort caps at ~2-3% for a multi-day cross-crate shader change. **Abandoned after measuring; do not rebuild it** unless targeting Metal/Mac (where readback may cost more) or unless the nexus solver gets much faster first.

**How to apply:** the only meaningful rollout lever is `env.step` itself = the **nexus GPU multibody solver** (biped_fps: ~79% solver compute, ~15% host encode, ~3% CPU obs/reward). That is upstream nexus work (fewer dispatches / better solver — the PhysX gap), not a zealot rollout refactor. See [[tier1-rollout-forward-cleanups]].

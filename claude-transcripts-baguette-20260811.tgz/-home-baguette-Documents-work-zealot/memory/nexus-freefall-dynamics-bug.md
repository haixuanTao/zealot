---
name: nexus-freefall-dynamics-bug
description: nexus instability was the joint MOTOR MODEL. First fix = AccelerationBased (stable but UNREALISTIC — inertia-decoupled tracking the real robot can't do; sim2sim diverges at the ankles). REAL fix (2026-06-17) = explicit force-based PD torque in the solver. See bottom.
metadata:
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

ROOT CAUSE of "nexus is 5–10x less stable than MuJoCo / nothing learns to stand" (localized 2026-06-16).

DECISIVE TEST: passive settle (BIPED_PASSIVE=1 in biped_render_nexus — added: holds default/zero pose,
action=0, no policy, no resets). Hold all joints at 0 from the standard spawn (torso z=0.72, all joints 0).
- MuJoCo (sim2sim_xval build_mujoco_model, identical spawn + PD): joints stay <0.12 rad, torso holds ~0.70.
- NEXUS: EVERY joint slams to its limit within 0.1s (hipy→±1.0, knee→-0.52, hipx→±0.35...), torso collapses.
  At STEP 1 (0.02s) joints already jumped ~0.3 rad from rest; symmetric (hipy_l=-hipy_r).

KEY: at spawn the feet are at z=0.035 (3.5cm ABOVE the floor — NO contact), and at step 1 the feet LIFT to
0.07–0.14m while the torso barely drops → the legs flex IN THE AIR. This is pure FREE-FALL articulated
dynamics. Physics: a body released from rest in uniform gravity falls RIGIDLY — internal joints have ZERO
relative acceleration (q̈_internal must be 0; requires the generalized gravity force g and mass matrix M to be
consistent so M⁻¹g has zero internal components). nexus produces large spurious internal joint accel in the
first step ⇒ g and M are INCONSISTENT in nexus's articulated dynamics (gravity_and_lu / compute_dynamics_pre /
the mass-matrix build). THIS is the bug; everything downstream (limit-riding, command-ignoring, ~0.2s
collapse, the 5–10x sim2sim gap) is a consequence.

RULED OUT (systematically): policy/reward/command (happens passively); contact (feet airborne at spawn);
motor params kp/kd→erp_inv_dt=kp/(dt·kp+kd), cfm — rapier-correct, and motor error=0 at step 0 so motors
apply ~0 force anyway; off-diagonal inertia (BIPED_DIAG_INERTIA=1 A/B explodes identically); solver
iterations (BIPED_SOLVER_ITERS=32 no help); implicit Coriolis (no help). PRE-EXISTING — not the recent
gravity_and_lu damping/frictionloss edits (at step 0 v=0 so those terms are 0).

PRIMARY DRIVER FOUND = ARMATURE MISPLACEMENT (2026-06-16). nexus has ZERO native armature support
(grep "armature|rotor|dof_inertia" across src_rbd*/ = nothing). The env (biped_env_nexus.rs ~line 390) HACKS
armature in by adding it to the link INERTIA TENSOR (`Izz`, via izz_extra before with_inertia_matrix), which
inflates the CRBA mass matrix M = JᵀIJ — but the gravity bias force is mass-only at rest and never sees it,
so M⁻¹g produces spurious internal joint accel. A/B via the existing BIPED_ARM scale knob on the passive
free-fall: BIPED_ARM=1.0 → step1 max|joint|=0.396; BIPED_ARM=0.0 → 0.069 (5.7x less). Armature is the dominant
first-step driver. RESIDUAL: even ARM=0 still slowly buckles (step5=0.796) — a second issue (likely stiff-PD
numerical softness on low-inertia joints, which is WHY armature was added in the first place — but to the
wrong place).

CORRECT FIX (the MuJoCo/rapier way): add per-DOF armature to the CRBA mass-matrix DIAGONAL, NOT the inertia
tensor. Exact site: compute_dynamics_pre.rs:621 already does `M[d,d] += damping_slice[d]*dt` — add an armature
term right there: `M[d,d] += armature_slice[d]` (no *dt). damping/frictionloss/velocities are env-major
dofs_cap×num_batches buffers (dof_state damping SECTION at batch_ids.dof_damping_section_offset; frictionloss
a separate Tensor binding 12 in gravity_and_lu, set via set_dof_frictionloss). Mirror that to add a
dof_armature buffer/section + setter + bind into compute_dynamics_pre + seed from robot.joints[k].armature, and
REMOVE izz_extra from the env inertia tensor. Adding to the M DIAGONAL (not JᵀIJ) keeps g/M consistent AND
stabilizes stiff PD. Needs a sm_120 cubin rebuild (build_cuda/build_nexus_cubin.sh; fragile — triton ptxas
12.8, see [[native-cuda-build-pinning]]). NOT a guaranteed-complete fix alone (residual to chase). Diagnostic
flags added: BIPED_PASSIVE, BIPED_DIAG_INERTIA, and existing BIPED_ARM.

ARMATURE FIX IMPLEMENTED + TESTED 2026-06-16 — DID NOT FIX IT (negative result). Implemented fully: per-DOF
dof_armature buffer plumbed into compute_dynamics_pre (binding 12 / 11 in the two kernels), added to the M
DIAGONAL next to the damping term (`M[d,d] += damping*dt + armature[d]`); GpuMultibodySet.dof_armature Tensor
+ set_dof_armature; env removes izz_extra from the inertia tensor and seeds dof_armature instead. Rebuilt cubin
(sm_120, EMBED HASH MATCH OK) + host + example. RESULT: passive free-fall STILL buckles to limits — step1
0.396→0.355 (tiny change, confirms the edit is live), step5 still 1.048, torso still collapses. So armature
PLACEMENT (tensor vs M-diagonal) is NOT the root cause.
REFINED UNDERSTANDING: armature added to M (either way) WITHOUT g-consistency perturbs free-fall — BIPED_ARM=0
(no armature anywhere) gives the SMALLEST step1 (0.069, nearly-rigid free-fall) but then still SLOWLY buckles
(step5=0.796). So (a) the free dynamics g/M is nearly consistent only when armature=0, and (b) the residual
slow buckling at ARM=0 = the MOTORS not holding the joints against gravity (constraint-based position motor
too soft: cfm_coeff≈34.7 for hipy = very compliant) and/or stiff-PD numerical instability on the tiny leg-link
inertia. MuJoCo holds because its position actuators are stiff enough + implicit armature handling. NEXT
SUSPECT = the nexus joint-MOTOR constraint strength (joint_constraints.rs motor_params erp/cfm; the motor is
too compliant to hold) — NOT armature, NOT the mass matrix gravity projection. The armature-on-diagonal
plumbing is KEPT (it's the correct modeling + infra) but is not the fix.

★★★ SOLVED 2026-06-16 — MOTOR MODEL was the bug. The env set MotorModel::ForceBased. In motor_params
(src_rbd_shaders/dynamics/joint.rs:154) ForceBased puts the compliance in `cfm_gain` (raw, NOT mass-normalized);
AccelerationBased puts it in `cfm_coeff` (mass-normalized). On the tiny-inertia leg joints ForceBased
under-realizes the commanded kp, so the position motors can't hold and a passive robot buckles to its limits in
~0.1s. FIX: set MotorModel::AccelerationBased in biped_env_nexus.rs (~line 488). HOST-SIDE — NO cubin rebuild
(shader already handles both via motor.model; MotorModel maps 0=Accel/1=Force, multibody.rs:1625). RESULT:
passive hold-zero now ROCK-SOLID — max|joint| 0.006 rad, torso 0.719 stable for the full 2s (vs ForceBased
buckling to 1.048 / collapse; steadier than MuJoCo). Confirmed first via BIPED_KP_SCALE (5x stiffer ForceBased
held → softness was the lever), then AccelerationBased fixes it at DEFAULT gains. A/B: BIPED_FORCE_MOTOR=1
reverts. Armature-on-M-diagonal KEPT (consistent with AccelerationBased). NEXT: RETRAIN on fixed nexus — the
real test (all prior runs were on the broken motor). Knobs left: BIPED_FORCE_MOTOR, BIPED_KP_SCALE,
BIPED_KD_SCALE, BIPED_ARM, BIPED_DIAG_INERTIA, BIPED_PASSIVE.
★★★ MOTOR MODEL, part 2 — AccelerationBased was UNREALISTIC; explicit force-based PD is the real fix (2026-06-17, v23).
An open-loop divergence diagnostic (scripts/sim2sim_divergence.py: feed the recorded nexus action sequence
to MuJoCo open-loop, overlay per-DOF) showed nexus stays upright (tilt <4°) while MuJoCo with the SAME joint
targets tips at 0.72s — diverging FIRST and MOST at the ANKLES (ankley/hipy/knee). Cause: AccelerationBased is
mass-normalized → realizes target ACCELERATION (inertia-decoupled, crisp tracking), which the real robot /
MuJoCo (force-based PD, τ=kp·err−kd·q̇, fixed gains) CANNOT do — worst at low-inertia ankles. So accel-based is
the unrealistic piece; the policy overfits to it.
The constraint-based ForceBased (cfm_gain) under-realizes kp → robot SAGS (v22: torso parked at 0.61, never
recovers). NOT viable.
REAL FIX: apply force-based PD as an EXPLICIT generalized-force torque inside the solver, bypassing the soft
constraint. Two shader edits + cubin rebuild:
  1. joint_constraints.rs emit_motor_constraint: early-return when motor.model==FORCE_BASED (slot stays inactive
     kind=0; init zeroing + the `if cons.kind!=0` back-solve guard make slot accounting safe).
  2. gravity_and_lu.rs after the damping block (before Phase-3 LU load): lane-0 loop over links, for each
     FORCE_BASED motor add τ = clamp(stiffness·(target−q) − damping·q̇, ±max_force) to gen_forces[gen_base+abs_dof]
     (q=ws.coords.read(axis), q̇=vel_slice[abs_dof]). rhs_offset==gen_base so it enters the accel solve. By-VALUE
     motor read (cuda-oxide drops dynamic index on &motors[axis]). AccelerationBased (model 0) untouched.
RESULT (v23, BIPED_FORCE_MOTOR=1 now = explicit PD): trains like the stiff accel runs — torso HOLDS 0.65→0.71,
falls 1760→117 by iter 80 (vs constraint-force v22 sagging to 0.61). Realizes kp exactly AND is the faithful
real-robot/MuJoCo law.
CONFIRMED (v23, iter ~190 standing policy): closed-loop sim2sim survival jumped 1.74s → **6.00s (full rollout,
did NOT fall, 3cm drift vs 58–63cm staggering before); ratio mujoco/nexus = 1.00, verdict SIMILAR**. The motor
model was the dominant sim-to-sim gap. Open-loop divergence onset moved 0.72s→1.02s and the ankle is no longer
the lead diverger (residual split is open-loop-unstable balancing + contact/integrator diffs, expected).
NOW THE DEFAULT: biped_env_nexus.rs motor_model defaults to ForceBased (explicit PD); BIPED_ACCEL_MOTOR=1 opts
back to AccelerationBased for A/B. Binary rebuilt with the new default + new cubin.
See [[nexus-contact-model-realism]], [[sim2sim-policy-crossval]], [[limit-riding-and-logstd-collapse]], [[native-cuda-build-pinning]].
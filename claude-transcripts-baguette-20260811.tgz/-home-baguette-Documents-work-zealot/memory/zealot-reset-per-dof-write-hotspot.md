---
name: zealot-reset-per-dof-write-hotspot
description: Cold-start reset costs ~90 µs/env and is 42% of an iteration; ~70% of that is the per-DOF 4-byte write_buffer loop in the reset-velocity randomization.
metadata: 
  node_type: memory
  type: project
  originSessionId: 81953d33-c9bf-4579-b61e-bc2320be88e4
  modified: 2026-08-07T22:25:33.002Z
---

Measured 2026-08-07 while benchmarking against AGILE
([[zealot-vs-agile-benchmark]]). `reset` is negligible warm but dominant cold,
and it is linear in the fall rate — i.e. it taxes exactly the early-training
regime every run pays through.

| regime | resets/iter | reset time | per-reset |
|---|---|---|---|
| warm (resumed v29) | ~125 | 0.01 s | ~80 µs |
| cold (fresh policy, iter 30) | ~35k | 2.20 s | ~63 µs |

Cold that is 2.6 s of a 6.2 s iteration (42%).

**Hotspot**: the reset-velocity randomization in `reset_env`
(`src/biped/biped_env_nexus.rs`, ~line 4350) issues one `write_buffer` PER DOF,
4 bytes each — ~18 separate H2D copies per env reset — because the upstream
multibody layout is batch-interleaved (dof `d` of env `e` at `d·n + e`). The
code already admits it: *"Fine at reset frequency; a real port would batch
this."*

A/B via the `BIPED_RESET_VEL=0` knob, normalized for differing fall rates:
default ~82–92 µs/reset vs ~20–29 µs/reset with it off — so that one loop is
~65 µs of ~90 µs (~70% of reset cost).

**FIXED, in four stages** (2026-08-07/08). Reset went 2.20s -> 0.20s per
iteration at N=4096:
1. zealot `5aa1d00` + nexus `462bf3d` — velocities ride the snapshot dispatch
   (below).
2. nexus `4cb6b72` + zealot `09d734f` — BOTH scatters batched: `dst_envs` index
   buffer + env-major staging, one dispatch per rollout step instead of ~1700.
   New `gpu_rbd_env_reset_bodies` does the same for body_poses/vels.
3. nexus `f60c29a` + zealot `1643f52` — spawn teleport applied IN-KERNEL via a
   per-reset offset + topology-constant flag buffers, killing the per-reset
   `translated()` snapshot clone.
4. `BIPED_RESET_BATCH` caps envs per dispatch (default all); `=1` restores the
   per-env cadence and is the A/B lever.

Stage-1 detail — zealot master `5aa1d00` + nexus `462bf3d` (on branch
`feat/browser-web-demo`; nexus `origin/master` is a stale 2026-06-08 branch that
predates the whole snapshot-reset API, so the fix could NOT be landed there).
The velocities are now drawn before the reset and passed through the new
`RbdState::reset_env_from_snapshot{_offset,}_vels`, riding in the staging block
the reset dispatch already uploads. No cubin rebuild needed — the mb-env-reset
kernel signature is unchanged. Measured: reset 2.20s -> 0.68s per iteration,
cold iteration @4096 6.2s -> 4.4s.

Note the earlier fix in [[trainer-reset-readback-perf]] removed the per-reset
`slurp_poses` readback (that path now serves cached per-template spawn obs);
this per-DOF write loop is the remaining cost. Contrast: AGILE's reset is fully
GPU-vectorized — its iteration time stayed flat at 2.88 s while its episode
length fell 23.5→4.0 steps.

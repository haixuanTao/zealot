---
name: v58-net-asymdr-no-transfer-gain
description: "v58 (NET symmetry + per-joint asym DR, 15k iters) trained cleanly but did NOT improve sim2sim transfer — gap persists."
metadata: 
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

v58 = biped_train_gpu, 15000 iters @ 2048 envs, BIPED_MIRROR_NET=1 + per-joint
asym DR (BIPED_ASYM_DR=0.15 default), native CUDA + graph. Checkpoint
/tmp/v58_net_asymdr.safetensors.

Training arc: clean. step_rew −0.358 (iter0, standing) → +0.038 peak (iter ~8k,
curr 0.58) → settled ~0.017 at full command (curr 1.0, iter 12k+). Falls 2847 → 75
(low) → ~265 at full command. The reward dip after iter ~8k was the velocity-command
curriculum ramping to full, NOT instability.

**sim2sim (MuJoCo closed-loop, cmd 0.4 m/s): ~71 steps survival, 7 falls/500 (reset
every ~71 steps ≈ 1.4s).** Compare v56 ~80, v57 ~67 → v58 is statistically the SAME.

CONCLUSION: NET symmetry + per-joint actuator asym DR train fine and add a real
sim-to-real robustness property (handles one-motor-stronger asymmetry), but do NOT
close the sim2sim transfer gap. Consistent with [[contact-fix-no-transfer-gain]] and
[[sim2real-gap-hipz-dynamics]]: the gap is in the PD/motor/structural initial
response (nexus vs MuJoCo dynamics), not something reward/symmetry/DR can fix. The
real blocker remains the nexus dynamics fidelity (task #27), not the policy.

---
name: sim2sim-policy-crossval
description: Closed-loop sim-to-sim policy cross-val harness (nexus-trained policy run reactively in MuJoCo) + the lag-2 obs quirk it exposed.
metadata:
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

SIM-TO-SIM POLICY CROSS-VAL 2026-06-15 (user asked for the "B test" = deploy the SAME policy in MuJoCo
and compare to nexus, NOT passive dynamics A/B, NOT the open-loop replay).

`scripts/sim2sim_xval.py` — CLOSED-LOOP: loads a zealot safetensors policy, rebuilds the 43-dim obs
from MuJoCo state each control step, runs the actor, applies action as PD target, steps MuJoCo. CPU-only
(MuJoCo), does NOT touch the GPU. Run: `python3 scripts/sim2sim_xval.py [rollout.json] [policy.safetensors]`.
Reusable on any future policy via CLI args — RE-RUN ON A REAL WALKER once we have one (v7 is a non-walker).

3-phase validated against a Rust ground-truth dump (biped_render_nexus.rs now also dumps per-step `obs`(43)
+ `actions`(12) into the rollout JSON; generate with `BIPED_RENDER_DET=1 ... biped_render_nexus 0 400
out.json policy.safetensors`):
- Phase 1 net parity: normalize→ELU-MLP reproduces dumped actions to 7.5e-6. (net = actor.w_l/b_l, ELU
  hidden + LINEAR output; Welford normalize = clip((x-mean)/sqrt(max(m2/count,1e-8)),±5); keys obs_norm.mean/m2/count.)
- Phase 2 obs reconstruction parity: proj_grav + joint order + quat conventions exact (1e-5).
- Phase 3 closed-loop MuJoCo rollout + nexus comparison.

OBS PIPELINE QUIRK (non-obvious, real — Phase 2 caught it, NOT overfitting): in the dumped/rollout obs,
`last_action` is **lag-2** (= action[t-2]), with a **2-step warmup** (zeros on the post-reset fresh step
AND the next), and `command` is zeroed for exactly the one post-reset fresh step but NOT step 0. Root cause:
env.step builds obs in par-compute using `self.last_action` BEFORE the serial commit updates it, and the
render loop reads obs from the NEXT step's `outs.obs` — so a freshly-applied action only appears in obs two
steps later. Matters for any obs-replication / sim-to-real export. Obs layout:
[last_action(12, lag-2), command(4)=[vx,vy,yaw,0], joint_pos_rel(12)=q (default_pos all 0), joint_vel(12),
proj_grav(3)=quat_rotate_inv(base_quat_xyzw,[0,0,-1])]. Axes FWD=x LAT=y UP=z. action_scale: hipz .733/
hipx .55/hipy .367/knee .367/anklex .55/ankley .55. target = scale*action (default 0). Joint order =
JOINT_NAMES (anklex_l/r, ankley_l/r, hipx_l/r, hipy_l/r, hipz_l/r, knee_l/r).

FAITHFUL MUJOCO MODEL (corrected after user challenged "are we fully using MuJoCo?" — the ANSWER WAS NO):
the first build_mujoco_model regex-STRIPPED every mesh-referencing geom, which DELETED the real mesh foot
colliders (robot.xml feet are `type="mesh" class="collision"` with tuned condim=3/solref="0.005 1"/solimp/
friction=0.6/priority=1) and ran on leftover capsules + MuJoCo DEFAULT Euler solver. Fixed: build_mujoco_model
now compiles the shipped canonical scene `~/tmp_eval/mjcf/sim_scene_safe.xml` config — `integrator=implicitfast,
solver=Newton, dt=0.005` (matches nexus 1/200) — with `<include robot.xml>` (real mesh colliders + per-joint
damping+frictionloss+armature + visual meshes), plus TWO corrections: (1) `inertiafromgeom="false"` so MuJoCo
uses the explicit per-link <inertial> (12.7 kg, same as nexus) NOT geom-recomputed inertia (the shipped scene's
`inertiafromgeom="true"` inflates to 20.3 kg); (2) actuator forcerange = effort caps 88/88/88/88/44/44 N·m
(nexus's set_motor_max_force; sim_scene_safe omits them). PD kp/kv already match zealot. The model has BOTH
collisions and visual meshes so ONE model serves physics + render (render_sim2sim_mujoco.py renders from it
directly, default geomgroup shows meshes). MJCF colliders exist only on FEET+THIGHS (shins/hips/torso none —
true in both engines). Writes ~/tmp_eval/mjcf/_xval_scene.xml.

RESULT (v7, a non-walker, FAITHFUL model): MuJoCo survived 1.28 s (64 ctrl steps) vs nexus v7 ~0.24 s (~12
steps) = 5.4x LONGER in MuJoCo. NEXUS IS THE HARSHER/LESS-STABLE ENGINE (consistent with the training plateau
being sim instability, not reward tuning) — NOT the policy exploiting easy nexus contact. Inconclusive for true
transfer since v7 falls in both; the real B verdict waits for a walker. (The earlier DEGRADED model gave 0.76 s
/ 3.2x — superseded.)

ASSET PATH (IMPORTANT): robot.xml's 54 visual STL meshes ARE on disk at `~/tmp_eval/mjcf/assets/` (NOT the
stale `lerobot-humanoid-design/.../urdf/assets` path that cross_engine_eval.py + render_biped_mujoco.py
hardcode — that dir is gone). The sim2sim harness PHYSICS model strips visual meshes and uses capsule
collisions (validated, fine for the closed loop). For VIDEO, `scripts/render_sim2sim_mujoco.py` builds
a SEPARATE mesh model with `meshdir=~/tmp_eval/mjcf/assets` (override via BIPED_ASSETS) and plays the recorded
qpos trajectory through it — DON'T render the capsule model, it looks like a blob and the user (rightly)
rejected it. Render: `python3 scripts/render_sim2sim_mujoco.py [rollout.json] [policy.safetensors]
[out.mp4] [steps]` (EGL headless, 720p, resets-on-fall so the clip shows multiple attempts; collision geoms
are group 3 = hidden by default, visual meshes show with default geomgroup).

MASS NOTE: capsule physics model sums to 14.38 kg vs zealot's `total_mass=10.18` constant — likely the
constant is a stale rough note (real MJCF inertials sum higher); worth confirming zealot's parsed per-link
masses match the MJCF. See [[per-component-reward-wandb-logging]], [[prefers-natural-motion]].

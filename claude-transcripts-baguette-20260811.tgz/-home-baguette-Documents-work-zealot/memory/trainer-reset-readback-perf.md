---
name: trainer-reset-readback-perf
description: The dominant non-physics cost in biped_train_gpu was per-reset overhead in reset_env (full slurp_poses readback + scene rebuild); fixed for ~31% faster iters.
metadata:
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

PERF (2026-06-16): biped_train_gpu was ~2.9 s/iter at 2048 envs (vs Isaac/WBC-AGILE 0.74 s, ~3.9x). Traced
the NON-physics cost to `reset_env` (biped_env_nexus.rs), called once PER FALLEN ENV PER STEP (~5–6k times/
iter — and the per-iter time SCALED WITH FALLS: 2.2 s @1937 falls → 2.9 s @6000, ~175 µs/reset). Each reset did:
(1) `build_env_scene(...)` — rebuilding the whole rapier scene just to read foot_sole_local, and (2) a full
`slurp_poses()` GPU→host readback of ALL envs' poses to compute the one env's spawn obs.

FIX 1 (small, ~4%, provably-identical): cache `foot_sole_local` per template at construction
(template_foot_sole) — it's constant per template. reset_env looks it up; no scene rebuild.
FIX 2 (big, the real win): ELIMINATE the per-reset readback. The post-reset obs is deterministic from the
template spawn state (joints 0, vel 0, last_action 0) and the velocity command enters obs ONLY at [12:16]
(VelocityFlatTask::observe). So cache each template's spawn obs/critic_obs in `initial_obs` (env t holds
template t before any reset) and reset_env serves the cached vector with the fresh command patched into
[NUM_JOINTS..NUM_JOINTS+4] — NO slurp_poses. VERIFIED bit-identical to the live readback path (obs & critic
maxdiff = 0.000e0 across all resets/templates) via the BIPED_VERIFY_RESET=1 self-check left in reset_env.

RESULT: 2.9 → 2.0 s/iter steady (~31% faster), and FLAT in falls (1.8→2.0 vs 2.2→2.9) since the fall-scaling
readback is gone. 20k-iter run 15.5 h → ~11 h. Isaac gap 3.9x → 2.7x @2048. All host-side, no cubin rebuild.
Both fixes are in v14 (the live walking run) + the stand-before-walk curriculum. NOT yet committed/pushed.
Remaining speed ideas (not done): per-epoch KL slow_read_vec ×2 (compute once), record_obs host loop, CUDA-graph
capture for rollout physics (~15% per [[cuda-graph-capture-unlock]]), cuBLAS for the PPO GEMM (CUDA-only).
See [[limit-riding-and-logstd-collapse]], [[nexus-freefall-dynamics-bug]].

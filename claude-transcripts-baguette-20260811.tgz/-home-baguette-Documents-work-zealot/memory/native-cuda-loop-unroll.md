---
name: native-cuda-loop-unroll
description: The cuda-oxide loop-unroll win (HANDOFF_5090) reproduces on the 5090 but only +3% — libNVVM was already near-optimal; the big win was a 4090/llc-path thing.
metadata: 
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

Took the HANDOFF_5090 cuda-oxide loop-unroll win (`!llvm.loop.unroll.full` hint, gated by `CUDA_OXIDE_UNROLL_LOOPS`) to the 5090 box. It reproduces and is correct, but the 5090 net gain is small.

**Assembly:** merged cuda-oxide `feat/loop-unroll-metadata` (fast-forward, 1 commit, dialect-llvm) into `feat/nexus3d-vortx-native-cuda`; rebuilt `librustc_codegen_cuda.so`. Wrote `nexus-cuda/build_cuda/build_cubin_unroll.sh` (generalized over crate, DO_UNROLL + fp-contract flags) and `build_libnvvm_unroll_both.sh` (libNVVM path for both cubins).

**Two gotchas the inherited scripts had wrong (cost the initial regression):**
1. `build_nexus_cubin.sh` used the **rust-nightly LLVM-20** tools (`opt/llc`); the cuda-oxide backend emits LLVM-21 IR → LLVM-20's loop-unroll silently ignores the hint (no-op). Fix: use `~/llvm21/bin` (LLVM 21.1.0).
2. The llc path emitted separate FMUL+FADD (FFMA=0) → ~2× FP instructions. Fix: `llc --fp-contract=fast` → `gemm_tiled` becomes **256 FFMA** (the handoff's success criterion). Verify FFMA with grep (cuobjdump SASS); an awk `\b` bug gives false FFMA=0.
   - cuobjdump for sm_120: system CUDA 12.0 can't; use Triton's (`~/.local/.../triton/backends/nvidia/bin/cuobjdump`).
   - `cargo clean -p` doesn't clear the nvptx64 artifact → `touch` the shader `src/lib.rs` to force recompile.

**Results (N=8192, iter_e2e_bench, new Isaac config iters=4):** WebGPU 29.8k · llc+unroll+FFMA 34.9k · **libNVVM (no unroll, prior baseline) 41.5k · libNVVM+unroll 42.75k (new best)** · N=16384 43.1k. Validated: boxes3d_cuda 200 steps 0 NaN; biped gather err 0.0; no hang.

**Why only +3% (vs the 4090's ~2.3×):** libNVVM is a production compiler that already unrolls/fuses these kernels, so the explicit hint adds little on top. The big handoff win was relative to the 4090's bare **llc** path (no libNVVM). On the 5090, **libNVVM dominates llc regardless of unroll** — the unroll matters only on the llc path. See [[nexus-solver-cost-knobs]] (solver is dispatch-bound, so iteration env/s plateaus past N≈8k). To embed at zealot build time: `CUDA_OXIDE_SHADERS_PTX_{NEXUS_RBD_SHADERS3D,VORTX_SHADERS}` → the cubins in `~/nexus_ptx`.

---
name: nexus-solver-cost-knobs
description: "The nexus GPU solver is the rollout's 95% cost; solver substeps (SOLVER_ITERS=8) and implicit_coriolis are the big perf dials — large speedups measured."
metadata: 
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

`env.step` (the nexus GPU multibody solver) is ~95% of a control step and ~79% of that is raw solver compute (see [[tier2-gpu-resident-rollout-not-worth-it]]). The solver runs ~321 GPU dispatches/control-step at 4 substeps; zealot runs **8** substeps, so ~600. The dominant cost multipliers are the per-substep kernel chain (× num_substeps) and the contact-solver color loops.

Two cost dials in `examples/biped/biped_env_nexus.rs`. **Defaults were changed to match Isaac Lab/PhysX** (the benchmark reference) on 2026-06-08:
- **`SOLVER_ITERS` now = 4** (was 8) → `sp.num_solver_iterations`. Mirrors PhysX `solver_position_iteration_count = 4` for velocity locomotion. The master multiplier — every per-substep kernel chain runs this many times. Override via `BIPED_SOLVER_ITERS` (=8 for old setting). Note: the CPU rapier env (`biped_env.rs`) still uses 8, so CPU and GPU fidelity now differ.
- **Coriolis now defaults to EXPLICIT** (`set_implicit_coriolis(false)`) → matches PhysX's Featherstone ABA (explicit Coriolis bias forces). Override with `BIPED_IMPLICIT_CORIOLIS=1` to restore nexus implicit handling.

Net: the default GPU env now runs the Isaac-matching config = the "fast" config below (~66.9k env/s at N=2048, +90% over the old default), verified stable (mean torso z −0.31, no blowup/NaN).

Measured (biped_fps, N=2048, GPU env-ctrl/s), all with no NaN/blowup in the zero-action probe:
- iters=8 cor=on (baseline): **35.1k**
- iters=8 cor=off: 48.3k (**+38%**)
- iters=6 cor=on: 42.5k (+21%)
- iters=4 cor=on: 56.7k (+62%)
- iters=4 cor=off: **66.7k (+90%)**

**How to apply:** these are physics-FIDELITY tradeoffs, not free — the zero-action probe only proves the solver doesn't explode, not that a policy still learns a good gait. A short `biped_train_nexus` run (12 iters, 1024 envs) confirmed the reduced-fidelity config (iters=4 cor=off) trains with NO pathology (no NaN/divergence, same qualitative early trend as baseline) — but 12 iters is far too few to prove final gait quality. A full training-to-gait run is still recommended to confirm final policy quality at the new (Isaac-matching) defaults — the 12-iter check only proved no pathology, not equal gait quality. iters=6 is the low-risk +21%; iters=4+coriolis-off is the aggressive ~+90% pending training validation. Behavior-preserving dispatch cuts (eliminating the per-color `reset_color`/`inc_color` grid-1 dispatches via push-constant color index) are a separate, bit-exact-but-shader-surgery option not yet done.

**Roofline (measured 2026-06, native CUDA via nvidia-smi util/power/clock sampling — ncu SOL blocked: ERR_NVGPUCTRPERM perms + ncu 2022.4 predates sm_120; nsys --stats importer also broken on this box):** the solver is **latency / dispatch-overhead bound — NOT memory-bandwidth bound and NOT compute-throughput bound.** Physics-rollout window (N=8192): mem-controller util **~3%**, power **~183W/600W (~30% TDP)**, SM clock pegged ~2.96GHz, gpu_util ~77% (time-based). Full iteration similar (mem 2.5%, power 149W). Memory idle + low power + pegged clocks = launching/syncing many small light kernels (`multibodies_per_batch=1` → `[1,N,1]` grids, ~600 dispatches/step). So the real lever is **kernel fusion / wider grids / fewer dispatches**, not bandwidth or FLOPs — a faster-memory or higher-FLOP GPU would barely help. (The GEMM PPO update is the lone compute-bound piece; README vec4 experiment.) The "~79% solver compute" figure above is GPU-busy *time*, not throughput saturation.

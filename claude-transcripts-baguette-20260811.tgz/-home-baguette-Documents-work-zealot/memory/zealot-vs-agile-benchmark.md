---
name: zealot-vs-agile-benchmark
description: "Measured 2026-08-07 — after fixing substep-refresh + reset, zealot is 1.4x FASTER than AGILE/Isaac at 4096 envs and ties at 8192, using half the VRAM and a quarter the RAM."
metadata: 
  node_type: memory
  type: project
  originSessionId: 81953d33-c9bf-4579-b61e-bc2320be88e4
  modified: 2026-08-07T22:24:55.791Z
---

Matched benchmark on the 5090 box (RTX 5090 32 GB, Ultra 9 285K 24c, 62 GB RAM),
2026-08-07. Both stacks at defaults: 50 Hz control / 200 Hz physics /
decimation 4, 24-step rollout, same PPO net + hyperparams, rough terrain +
curriculum, headless, N iterations from a fresh policy.
zealot = `cargo run --release --bin biped_train_gpu --features "gpu biped_gpu cutile"`.
AGILE = `scripts/train.py --task Velocity-G1-History-v0 --headless`.

**Headline (zealot AFTER the two fixes in [[zealot-substep-refresh-regression]]
and [[zealot-reset-per-dof-write-hotspot]]):**

| metric | zealot @4096 | AGILE @4096 | zealot @8192 | AGILE @8192 |
|---|---|---|---|---|
| s/iter | **1.0** | 2.90 | **1.8** | 4.01 |
| env-steps/s | **98.3k** | 33.9k | **109k** | 49.1k |
| VRAM peak | **5.46 GB** | 10.43 GB | **8.43 GB** | 14.47 GB |
| RAM peak | **1.17 GB** | 8.15 GB | **1.82 GB** | 10.81 GB |
| GPU util (steady) | 63% | 73% | 52% | 74% |
| CPU (steady) | 2.5 cores | ~1.5 | 2.1 cores | ~1.7 |

So: zealot 2.6x faster at 4096 and 2.0x at 8192. Memory is a blowout win at both
sizes. Scaling also improved: 4096->8192 now costs 1.82x time for 2x envs
(+10% throughput), where pre-fix it was 2.0x (flat).

Full arc at 4096 on 2026-08-07/08: 6.2 -> 4.4 (reset-vel batching) -> 2.1
(substep-refresh default) -> 1.9 (batched mb scatter) -> 1.7 (batched body
scatter) -> 1.6 (in-kernel spawn teleport) -> 1.5 (template bank) -> 1.3 (fused
PPO batch staging) -> 1.2 (motor-target scatter) -> 1.1 s/iter (fused policy
forward staging). -> 1.0 s/iter (row-blocked + arena staging). 6.2x total. See
[[zealot-host-staging-fusion]].

MEASURE UTILISATION ON THE TAIL, not the whole run: startup (cargo check + cubin
load + terrain build + graph warmup) is now ~74s, i.e. MORE than half a 60-iter
run's wall clock, so whole-run gpu_util means read ~38% when steady state is
~60%.

The pre-fix numbers (6.2 s/iter @4096, 15.9k steps/s, "AGILE is 2.1-3.0x
faster") were a MEASUREMENT OF TWO BUGS, not of the stack. Don't quote them.

Other durable facts:
- **STALE, CORRECTED 2026-08-09**: "zealot is now HOST-bound" was true at 2.1
  s/iter but the host work has since been optimized away. Measured per-step at
  4096 warm (0.99 s/iter): gpuwait **25.3 ms (85.8%)**, reward 2.0, commit 1.3,
  readback 0.7, stage+flush 0.2 — total 29.5 ms x 24 steps. The host is blocked
  on PHYSICS 86% of every step. zealot is GPU-BOUND again. The entire remaining
  host block is 4.0 ms/step = ~8% of an iteration, which is the CEILING on the
  GPU reward/obs port ([[gpu-reward-port]]). Next real wins are physics kernels,
  not host work.
- Scaling: zealot 4096->8192 costs 2.0x time (throughput flat); AGILE only
  1.38x (+45%). AGILE still amortizes fixed overhead far better, which is why
  it catches up by 8192. That is the remaining structural gap.
- Not perfectly matched: zealot's G1 MJCF is 25 simulated DOF / 12 policy
  actions; AGILE's `g1.usd` is 29 DOF / 14 actions (legs + waist_roll +
  waist_pitch) with a 5-frame obs history. AGILE simulates MORE. NOTE the waist
  IS simulated in zealot, just PD-held via `spec.held_joints` (300/5), not
  policy-actuated.
- The engine is NOT run-to-run deterministic: same binary, same seed, 6 iters
  @1024 gave term_fell 7402 vs 7328. A/B reward comparisons at this scale need
  repeats; bit-identity can't be asserted from a single pair of runs.
- `--features cuda_backend` without `cutile` costs +2.2 s/iter (PPO update
  encode 2.31 s vs 0.08 s). Production is `--features "gpu biped_gpu cutile"`;
  the older note that `cuda_backend` is the flag is stale.
- The README's "~71k env-steps/s at N=4096" still doesn't reproduce (46.8k
  measured post-fix). Probably an `iter_e2e_bench` one-shot without
  resets/rewards/terrain.

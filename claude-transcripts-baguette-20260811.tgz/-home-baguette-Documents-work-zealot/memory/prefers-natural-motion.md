---
name: prefers-natural-motion
description: User values realistic/natural robot motion (the sim-to-real fidelity payoff) over a policy that merely stays upright with unnatural motion.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

The user judged the v7 clip (mid-training, ~iter 360/2000, falls often) as "the best clip so far" —
over earlier policies that balanced longer but moved unnaturally.

**Why:** v7 was the first render with ALL the fidelity fixes active (real joint limits + damping +
frictionloss + off-diagonal inertia). The motion looks natural — realistic joint speeds (~36 vs 50+ rad/s),
joints within real ranges (no foot-into-shin), no body clipping through the floor — even though it falls
more because it's only ~18% trained. Earlier "stays upright" clips moved unnaturally (50 rad/s jitter,
±180° joints, sub-floor penetration).

**How to apply:** prioritize MOTION REALISM (the fidelity work) — it's visibly valued — and don't trade it
away for a policy that just survives longer with jittery/unphysical motion. When showing progress, natural
motion + some falls reads better than unnatural balance. The remaining piece for actual walking is the
velocity-tracking reward rebalance (forward stride), NOT more fidelity. See [[fragile-ankle-hardware]] and
[[native-cuda-build-pinning]] for the fidelity fixes; the stand-still local optimum is the walking blocker.

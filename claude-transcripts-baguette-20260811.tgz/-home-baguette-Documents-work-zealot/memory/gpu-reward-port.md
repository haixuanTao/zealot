---
name: gpu-reward-port
description: "GPU port of the trainer's reward/state/obs block — all 32 terms + state + feet history + obs assembly done and verified, but consumption never switched. MEASURED CEILING ~8%; the real bottleneck is physics (gpuwait 86%)."
metadata: 
  node_type: memory
  type: project
  originSessionId: 81953d33-c9bf-4579-b61e-bc2320be88e4
  modified: 2026-08-08T22:33:17.522Z
---

Done 2026-08-08/09 to reclaim the step tail (~0.094 s of a 1.0 s iteration at
N=4096: `reward` 1.9 ms/step + `commit` 1.3 + `readback` 0.7, ×24 steps ≈ 9%).

## VERDICT (corrected twice — read all of this before acting)

**The target is the obs ROUND TRIP, not reward, and not obs assembly.**

Measured @4096 with `BIPED_SKIP_REWARD` / `BIPED_SKIP_OBS` A/Bs (`b5e79d7`):
- host `task.reward()` — all 32 terms — costs **~0.1 ms/step**
- host `observe`+`observe_critic` costs **~0.1 ms/step**
- so the [prof] `reward=2.0` column is the WHOLE per-env block; state
  derivation (`read_state_from_poses` + `compute_feet_from_poses`) is ~1.7 ms
  of it, and reward/obs are ~5% each.

CAVEAT on the SKIP_OBS A/B: zeroed obs => random policy => fall rate spikes
(reset 0.01 -> 0.09 s), which moves step/post/gpuwait for unrelated reasons.
ONLY the par-block column is readable from it. `norm` stayed 0.02 s in both
runs because the vectors kept full length, so `fill_raw` still ran — that is
what isolates assembly from transfer.

**What device-residency actually removes** (obs never crossing PCIe):

| item | ms/step | source |
|---|---|---|
| `norm` — fill_raw transpose + upload | ~0.83 | measured (0.02 s/iter / 24) |
| `post` — gc/gcc `clone_from` | ~0.83 | measured |
| `readback` — slurp_poses 6.8 MB | 0.7 | measured, mostly removable |
| state derivation | ~1.7 | inferred (1.9 - 0.1 - 0.1) |
| minus the GPU path | -0.5 | measured |
| **NET** | **~3.6** | **~12%, 1.0 -> ~0.91 s/iter** |

So the port is NOT dead. It was killed on the wrong metric (twice). The pieces
built this session are the right pieces: `gpu_observe` already emits the exact
`[dim x n]` layout `fill_raw` produces, so it can write STRAIGHT into the
trainer's step-blocked `raw_obs`/`raw_cobs`, and the PPO staging kernel
(normalize+clamp+mirror on device) consumes it unchanged.

## WHAT REMAINS, CONCRETELY

1. Point `gpu_observe`'s outputs at the trainer's `raw_obs`/`raw_cobs` at
   `step * dim * n` instead of its own tensors.
2. Trainer stops maintaining `gc`/`gcc` (biped_train_gpu ~1178) and stops
   calling `fill_raw` (gpu_policy ~277) — the policy forward reads `raw_obs`.
3. Truncation bootstrap `ac.value(&outs[e].critic_obs)` (~1166) needs critic
   obs for DONE-and-not-fell envs only — small targeted readback, not the batch.
4. `reset_envs` returns fresh host obs for respawned envs — must be written to
   the device buffer instead.
5. Then state derivation: stop `read_state_from_poses`/`compute_feet_from_poses`,
   keep state resident. Host still needs base xy for the terrain probe (tiny
   readback) and the `illegal_ground_links` predicate.

PRICE EACH WITH A `SKIP_` A/B FIRST. And beware: any A/B that corrupts obs
changes the fall rate and contaminates every other column.

## Status: COMPLETE BUT DORMANT

On GPU and verified against the host to float precision:
- all **32/32** reward terms
- all state derivation (joint, base, feet)
- feet history device-owned (air_time, last_td_foot, poses) incl. reset
- **obs assembly** (`gpu_observe`, `6b143cd`): actor + critic, verified 1.7e-5

The host still computes everything too, so the build is CORRECT and NOT FASTER.
This is dead weight until consumption switches — see the blocker.

| commit | what |
|---|---|
| `8bf5119` | `StepKnobs` — reward params resolved once (was ~500 `getenv`/iter) |
| `4d01314` | `cuda-oxide` feature on `zealot-obs-shaders` |
| `c45a589` | third cubin target + `.cargo/config.toml` |
| `6a92741` | action terms + `BIPED_VERIFY_REWARD` harness |
| `348a277` | base-dependent terms |
| `cd3dd93` / `bd5d447` | per-foot state / per-foot terms |
| `ec820ad` | gated gait terms |
| `bbc5177` | self_coll, chest_ang_vel, termination |
| `e1cb7fb` | feet history device-owned |
| `6b143cd` | obs assembly (actor + critic) + `BIPED_VERIFY_CUE` fixture |
| `dd8ad38` | encode/read split on all 10 bindings (done for a wrong reason) |
| `28ff9c5` | `encode_dev` device-to-device term inputs + `BIPED_FUSE_BENCH` |

## MEASURED 2026-08-09: the cost is PER-READBACK, not per-submit

`BIPED_FUSE_BENCH` times the same kernels one-submit-each vs one shared
encoder. Fusing submits saves NOTHING:

    unfused=0.132ms fused=0.125ms
    unfused=0.134ms fused=0.139ms

Two kernels cost ~0.135 ms either way => **~0.067 ms/kernel, ~0.74 ms/step**
for all 11.

TWO WRONG THEORIES I HELD, both refuted by measuring:
1. "zealot is host-bound" — stale; gpuwait is 25.3 ms = 86% of the step.
2. "11 sync points at ~0.2 ms each make the GPU path cost 2.5 ms/step" — wrong.
   That 2.5 ms was mostly the HOST COMPARISON LOOPS in the verify block. I
   flagged that as a caveat in the same message and then reasoned past it.
   The encode/read split (`dd8ad38`) was done for this wrong reason and gains
   nothing on its own (it is still fine to keep — it is a prerequisite for
   consolidation).

REAL ARITHMETIC: host work replaced 1.9 ms/step; GPU path 0.74 ms with 11
readbacks, ~0.2 ms estimated with one consolidated readback. Net **1.2-1.7
ms/step = 3-4% per iteration**.

COST DECOMPOSITION (`fc65018`), 2 kernels @4096:
  dispatch only 0.019 ms | +1 readback 0.053 | +2 readbacks 0.122
Dispatch ~0.01 ms/kernel (nearly free); each READBACK ~0.04 ms. All 11:
~0.1 ms dispatch + ~0.44 ms readback = 0.55 ms.

## EXACTLY WHAT REMAINS (two pieces, not one)

**(a) Output consolidation** — a gather kernel stacking the 11 output tensors
into ONE buffer so the step does a single readback: 0.55 -> ~0.18 ms/step.
Self-contained, ~1 h. PRODUCES ZERO SPEEDUP ALONE — it only makes (b) worth it.

**(b) The consumption switch** — THE ONE THAT PAYS. Host stops calling
`read_state_from_poses` / `compute_feet_from_poses` / `reward()` / `observe()`
and builds `PerEnv` from the GPU readbacks. Keep the `PerEnv` SHAPE identical so
the serial commit pass and the trainer are untouched — that is the risk
reduction. Fill: obs/critic_obs from `gpu_observe` readback; reward+comps from
the term kernels; fell from misc; new_air + td_foot from feet; new_joint_pos
from q; `illegal` stays host (cheap predicate over poses); the cue stays host.
Net after (a): 1.9 ms host - 0.18 ms GPU = ~1.7 ms/step = **~4%/iter**.

DO NOT do (a) without (b) — that is the pattern that produced 10 dormant
commits. And run a few-hundred-iteration reward/falls/gait comparison BEFORE
flipping (b)'s default: it is the one change the harness stops catching.

GENERAL LESSON: on this project every "it can't go faster" I produced was a
description of my own scaffolding, and every projected number was wrong in the
same direction. Measure the shape before theorizing about it — `BIPED_FUSE_BENCH`
took ~15 minutes and refuted a theory I had already committed code for.

## Why consumption still hasn't switched

UNBLOCKED as of `6b143cd` (obs assembly landed) but NOT DONE, because the
restructuring is large and the prize is 8%: it touches the rollout buffer, the
mirror-augmentation path, the truncation bootstrap (`ac.value(&outs[e]
.critic_obs)` runs the critic ON HOST), and the serial commit pass that owns
gait tracking, curriculum and W&B logging.

## The original blocker (solved by making the cue an INPUT)

Switching consumption means the host stops calling `read_state_from_poses`,
`compute_feet_from_poses` and `reward()`. But the block ends with
`task.observe(&state,..)` + `observe_critic(..)`, so obs assembly must move too.
And `observe()`'s last 5 slots are the step cue
(`biped_env_nexus.rs` ~3964):

```rust
let mut cue = t.probe(e, state.base.pos_xy[0], state.base.pos_xy[1], yaw);
let r = &mut self.rng[e].clone();
if r.range(0.0,1.0) < step_cue_dropout { cue = Default::default(); }
else { cue.distance += r.range(-dn,dn); cue.height += r.range(-hn,hn); }
```

Terrain probe = host data structure (portable). **Per-env RNG stream = not
portable** — reproducing it on device must be bit-exact or the DR noise the
policy trains against changes, which makes it a TRAINING EXPERIMENT, not an
optimization ([[perf-work-must-preserve-behaviour]]).

RESOLVED: `gpu_observe` takes BOTH cues as a `[10 x n]` input (noisy 5 then
clean 5) and only does the gate + clamp. The host keeps the probe and the RNG,
so the DR stream is untouched. Remaining design if consumption ever switches:
read back base pose only (`GpuBaseState::out_tensor` rows 0-3 + 11-12, ~115 KB
vs the 6.8 MB `slurp_poses`), probe on host, upload the cue, then a second sync
that waits only on the small kernels (~0.2-0.5 ms), not on physics.

Note step 3 (shrink `slurp_poses`) also depends on step 2 — poses are still
needed host-side while obs is.

## Traps found (each cost a debug cycle)

1. **`REWARD_COMP_NAMES` index != what you assume.** `comps[29]` is
   action_rate_rate, `comps[30]` is touchdown_vz. Check the assignment site
   (`comps[k] = ...`), not the names array.
2. **Host and demo derive joint angles DIFFERENTLY.** Trainer host uses
   parent-child poses + per-joint rest quat:
   `rel = rest.conj()*qp.conj()*qc; q = 2*atan2(rel.z, rel.w)`. `gpu_assemble_obs`
   reads `WS_JOINT_ROT` directly. The port must match the HOST.
3. **Generated `call()` orders args by BINDING NUMBER, not declaration order.**
4. Doc comments on kernel params are rejected — only allow/cfg/deny/etc.
5. **`cmd.speed()` includes yaw_rate**; the tracking clamp uses planar
   `sqrt(vx^2+vy^2)`. Cost a constant 3.5e-2 in `track_lin_vel`.
6. **Vacuous verification**: `chest_ang_vel` read 0.0 only because its weight
   defaults to 0. Re-run with `BIPED_CHEST_ANGVEL_W=0.02` before believing a
   0-diff. Always confirm a term is non-vacuous.
7. **Device ownership without reset propagation**: gave the feet kernel the
   history but not `reset` — `first_contact` FLIPPED (changes which gait terms
   fire, not just magnitudes). Any device-owned history needs its reset path.
8. **`prev_force` must stay host-owned**: host rolls it BEFORE reading the new
   sensor value and re-seeds on `has_prev_force`. The ordering is the contract,
   not the storage; copying storage without ordering diverged ~0.3.
9. **`git add -A` swept a 1.4 MB binary named `--iters`** into a commit — a
   checkpoint written by an earlier mis-parsed CLI arg. Now in `.gitignore`.
   Check `git status` before `add -A` in this repo.
10. Persistent output tensors + `matrix_uninit` — allocating per iteration via
   `Tensor::matrix(..,&vec![0f32;n],..)` host-zero-fills AND uploads (made the
   first device-staging attempt SLOWER, 0.09 -> 0.12 s).

Harness: `BIPED_VERIFY_REWARD` (also `_RESET`, `_STAGE`, `BIPED_CLAMP_PROBE`,
`BIPED_RESET_PROF`, `BIPED_ROLL_PROF`, `BIPED_STAGE_PROF`, `BIPED_RESET_BATCH`).
NOTE the harness compares GPU against the host path that step 2 DELETES — after
switching, the only reference is git history. Run a few-hundred-iteration
reward/falls/gait comparison BEFORE flipping.

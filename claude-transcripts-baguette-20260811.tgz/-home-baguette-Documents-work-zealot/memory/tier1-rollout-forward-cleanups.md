---
name: tier1-rollout-forward-cleanups
description: "Tier 1 rollout-forward cleanups applied to gpu_policy.rs (tiled GEMM, no per-step buffer realloc, no redundant sync) — correct but ~2% throughput."
metadata: 
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

Applied to `examples/biped/gpu_policy.rs` (the rollout's batched policy forward, shared by rollout_e2e_bench / iter_e2e_bench / rollout_bench):
- `dispatch_naive` → `dispatch_tiled` GEMM (the update path already used tiled).
- `set_input` now overwrites the persistent `a[0]` in place via `backend.write_buffer(.., x.transpose().as_slice())` (matrix_from_na is row-major) instead of allocating a fresh Tensor each step; `a[0]` created with `STORAGE | COPY_DST`.
- Removed the redundant `backend.synchronize()` before the readbacks in `forward` (the `slow_read_vec` drains the queue anyway).
- Same tiled-GEMM swap in `policy_forward_bench.rs`.

Bit-exact preserved (iter_e2e gather err 0.000e0; policy_forward_bench err 4.8e-7). Throughput gain ~2% at N=2048, noise at N=256 — because the forward was never the bottleneck (GPU forward compute ~1.2 ms vs ~70 ms physics). Kept as hygiene. The forward is NOT worth further optimization — see [[tier2-gpu-resident-rollout-not-worth-it]].

Diagnostics left in the benches: `policy_forward_bench` prints "R1 = .. ms/step" (readback cost); `rollout_e2e_bench` prints "[rollout split] forward/sample/env.step ms". Harmless; revert if pristine benches are wanted.

---
name: zealot-substep-refresh-regression
description: NEXUS_SUBSTEP_REFRESH defaulted to 1 and cost ~5x the physics bill (114.6 vs 22.5 ms/step); fixed by defaulting to 0 in zealot master 5aa1d00.
metadata: 
  node_type: memory
  type: project
  originSessionId: 81953d33-c9bf-4579-b61e-bc2320be88e4
  modified: 2026-08-07T22:25:10.259Z
---

Found 2026-08-07 while benchmarking against AGILE ([[zealot-vs-agile-benchmark]]).

`NEXUS_SUBSTEP_REFRESH` = 1 rebuilds multibody dynamics + constraints EVERY
substep; 0 does it once per control step. Measured on the 5090, N=4096,
production config:

| mode | GPU per control step | s/iter |
|---|---|---|
| 1 (was default) | 114.6 ms | 4.4 |
| 0 (now default) | 22.5 ms | 2.1 |

~5x the physics cost of the entire trainer, from one knob.

How it crept in: the knob's nexus implementation arrived on the
`feat/browser-web-demo` branch (checked out 2026-08-05 18:43, replacing
`fix/mb-solver-consistency`), and when zealot consolidated knobs into
`zealot_env::knobs` (b9d9f91, 2026-08-07) it was declared with default 1.
That is exactly why **v29 ran at 3.9 s/iter where v28 ran at 2.5 s/iter**
(v28 started 2026-08-05 ~10:20, before the branch switch, gpuwait 62 ms/step).
Diagnosing this from the v28 log was the thing that cracked it — its `[prof]`
line has the same config as v29 but half the gpuwait.

Fixed in zealot master `5aa1d00`: default 0.

**CAVEAT**: refresh cadence changes the physics slightly. Train and eval with
the SAME setting — a policy trained at mode 1 (i.e. v29 and anything else
trained 08-05 → 08-07) is not guaranteed to transfer to mode 0. Set
`NEXUS_SUBSTEP_REFRESH=1` to restore. Also note falls/reward differ visibly
between modes at equal iteration, so it is not a free speedup.

Dead end worth not repeating: the cooperative-multibody commits
(`70639db`/`85246ac`/`240874d`/`74a5085`, the +41% work in
[[multibody-cooperative-rewrite]]) are NOT on `feat/browser-web-demo` — but they
are not on `fix/mb-solver-consistency` (what fast v28 ran) either, so their
absence was NOT the cause. The knob was.

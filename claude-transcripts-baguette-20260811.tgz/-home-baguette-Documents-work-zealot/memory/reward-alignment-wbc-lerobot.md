---
name: reward-alignment-wbc-lerobot
description: The biped finally learned to STAND once the reward was re-aligned from the wrong (G1) config to WBC-AGILE's lerobot config. The reward weights — not LR/pipeline/engine — were the standing blocker.
metadata:
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

BREAKTHROUGH 2026-06-17: the biped learned to STAND after re-aligning RewardWeights to WBC-AGILE's *lerobot*
velocity config (was ported from the WRONG robot — the G1 config). User's instinct ("we trained it on WBC,
check LR / reward") was right; LR was a red herring (zealot & WBC both 1e-3 adaptive desired_kl=0.01; zealot's
adaptive LR correctly settled ~1.3e-4 with KL pinned at target — proper-sized steps that just weren't improving
= a SIGNAL problem, not step size).

ROOT CAUSE: zealot's reward was "ported from WBC's G1 locomotion RewardsCfg" (G1 = different, larger robot).
The mismatches (zealot → WBC lerobot, from WBC-AGILE/agile/rl_env/tasks/locomotion/lerobot/velocity_env_cfg.py):
- base_height_target 0.62 → 0.72 (WBC DEFAULT_TRUNK_HEIGHT=0.72 = the spawn height). THE key bug: targeting
  0.62 while spawning at 0.72 made the reward push the robot to crouch 10cm into a fall.
- motion penalties were 5x too harsh: body_ang_vel/ang_vel_xy -0.25→-0.05, lin_vel_z -0.25→-0.05,
  dof_pos_limits -0.5→-0.1, feet_yaw_mean -2.0→-0.4, feet_distance -0.1→-0.02, foot_slip -0.05→-0.01,
  action_rate -0.25→-0.1, foot_orientation -0.5→-0.01. → over-punished the very motion needed to balance.
- flight -20.0 → 0.0 (WBC lerobot has NO flight/jumping penalty; the -20 was a huge anti-motion term).
- termination -25 (one-shot) → -2.0 (WBC is_terminated -100 ×control_dt 0.02 = -2.0 effective; zealot applies
  termination WITHOUT dt while per-step terms ARE ×dt, so -25 one-shot was ~12x harsher than WBC).
- dof_vel -1e-4→-2e-4, base_height weight 2.5→2.0. entropy_coef 0.005→0.01 (biped_train_gpu.rs ENTROPY).
All in velocity_flat.rs RewardWeights::default() + the ENTROPY const.

RESULT (v16, /tmp/biped_policy_v16, train_v16.log, 30k iters, BIPED_GRAPH=1, stand-before-walk curriculum):
falls 1937→~5 / 49152 env-steps by iter ~300, torso rose 0.68→0.73 (at target), reward went positive. NO
prior run (G1 reward) ever dropped below ~5500 falls in 20k iters. Sim2sim MuJoCo: v16 stands ~1.25s/attempt
(vs v15 0.56s) — improvement but a sim-to-sim gap remains (overfit to nexus; watch for real transfer).
NEXT: command ramps at iter 9000 (30% of 30k) — the WALKING test. Stand phase = command 0 (BIPED_STAND_FRAC).
See [[nexus-freefall-dynamics-bug]] (engine fix), [[limit-riding-and-logstd-collapse]], [[sim2sim-policy-crossval]].

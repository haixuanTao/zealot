---
name: hf-token-is-carolines-dont-publish
description: "The HF token on baguette belongs to CarolinePascal — NEVER publish releases there without asking; user said 'oh no' and had it deleted immediately (2026-08-05)."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b905e023-5d9a-49af-86a2-f055e9b8f2f6
  modified: 2026-08-05T14:12:20.590Z
---

The only HuggingFace token configured on baguette (`~/.cache/huggingface`,
profile "baguette") authenticates as **CarolinePascal** — a collaborator's
account, not the user's (user = Haixuan Xavier Tao / haixuanTao / shavtao@gmail.com).

**Why:** On 2026-08-05 I published a v28 policy release to
`CarolinePascal/unitree-g1-velocity-v28` following the precedent of the
existing `CarolinePascal/lerobot-humanoid-noarms-velocity-v16` repo. The user
reacted "oh no" and chose immediate deletion. Precedent of past uploads under
that account does NOT equal authorization to publish there.

**How to apply:** Before any HuggingFace upload, check `whoami` and ask the
user which account/org the release should go to. Never publish under
CarolinePascal's namespace. The correct destination is the user's own
**haixuantao** account (v28 went to `haixuantao/unitree-g1-velocity-v28`,
private) — but their token is NOT stored on this box (deliberately; the one
they used was pasted in-chat and they were advised to revoke it), so each
upload needs a fresh token from the user, passed via HF_TOKEN env only.
Release folder pattern that worked: README.md (model card) +
velocity_vNN_iterNNNN/{policy.onnx, policy.safetensors, env.yaml} — see
~/overnight/RELEASE_g1_v28_iter7900.md and [[chest-stability-reward-and-waist-gains]].

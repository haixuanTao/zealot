---
name: nexus-upstream-divergence
description: "Our nexus-cuda fork can't be merged with dimforge rustgpu-clean — divergent solver rewrites; upstream the 3 localized fixes instead."
metadata: 
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

Our `nexus-cuda` branch `feat/per-env-parallelism` (37 commits off merge-base `477854f`, May 17) **cannot be cleanly merged** with `dimforge/nexus-rustgpu` `rustgpu-clean` (23 commits ahead, the substantive upstream branch — `cuda` is only 2 commits/dep-bump ahead; there is NO `cuda-clean` branch).

Both sides independently rewrote the **multibody solver + pipeline** in incompatible directions:
- **Ours:** cooperative lane-split dispatch (`* MB_LU_LANES`), fused kernels (`remove_solve_contact_no_bias`), PGS sweep loops (`NEXUS_CONTACT_SWEEPS`/`STAB_SWEEPS`), `num_multibodies` buffer bindings, contact-realism (angfric/CFM), frictionloss, packed-DOF.
- **Upstream:** split joint kernel into `GpuMbInitJointConstraints`+`GpuMbSolveJointConstraints`, dedup, `batch_ids.multibodies_len` (dropped `num_multibodies`), invocation-per-mb model, `pipeline.rs` reworked +995/−301 (NexusPipeline split out of NexusState, non-blocking readbacks, batch-sim rework).

A merge "auto-merges" `pipeline.rs` (we barely touched it) → merged tree = upstream's new pipeline calling our old solver → **won't compose**. Reconciling = re-porting our features onto upstream's architecture (a multi-day port + full retrain to revalidate physics), NOT a merge.

**Decision: don't merge.** Instead (a) upstream our 3 localized correctness fixes, (b) treat any future sync as a deliberate rebase-onto-upstream project.

The 3 upstreamable fixes (all anchors confirmed present in upstream rustgpu-clean):
1. `2c2c31f` motor by-value copy in `init_joint_constraints_body` — fixes cuda-oxide dropped-index that inerts ALL motors on native CUDA. Shader-only, no binding change. **PR branch `upstream-pr/mb-motor-byvalue` (fe7d440) pushed to fork; ready.**
2. `7368be7` per-env collider friction (`MultibodyInfo.friction`) — upstream hardcodes 0.5, ignoring the rapier collider material. Re-applied to upstream rustgpu-clean (types + 4 contact sites + from_rapier param + pipeline ground-collider extraction); no new GPU binding. **PR branch `upstream-pr/mb-per-env-friction` (223f3c5) pushed to fork; ready (not locally cubin-built but layout-safe).**
3. `fa8b551` per-DOF armature on M-diagonal + frictionloss + damped ERP — adds NEW buffers/bindings AND has a KNOWN binding/layout fragility (our own commit msg: per-env SimParams wiring regressed training even with identical 30/5 values → had to hardcode). NOT pushed: must cubin-build + numerically validate first; ideally split armature (clean) from frictionloss/ERP.

PR base branch pushed to fork: `upstream/rustgpu-clean` (= dimforge tip 3316a10), so within-repo compares work on mobile. Fork's real name is `nexus-rustgpu2` (nexus-rustgpu redirects).

Worktree `../nexus-cuda-merge` + remote `dimforge` (git@github.com:dimforge/nexus-rustgpu.git) left in place. Fix #1 PR branch `upstream-pr/mb-motor-byvalue` (commit fe7d440) is pushed to `haixuanTao/nexus-rustgpu` (remote `fork`).

**BLOCKED on submitting the PR (2026-06-23):** `haixuanTao/nexus-rustgpu` is NOT a network fork of `dimforge/nexus-rustgpu` (its rustgpu-clean=505d234 ≠ dimforge's 3316a10; GitHub won't offer a cross-repo PR). Couldn't fix from here: gh token expired, no GH_TOKEN/GITHUB_TOKEN, this sandbox has NO HTTP egress to api.github.com (SSH git works, REST API does not), and the user (on a phone) can't fork. **RESUME from a laptop:** `gh auth login -h github.com`, then `gh repo fork dimforge/nexus-rustgpu --fork-name nexus-rustgpu-upstream --clone=false`, push the branch to it, `gh pr create --repo dimforge/nexus-rustgpu --base rustgpu-clean --head haixuanTao:upstream-pr/mb-motor-byvalue`. PR title/body already drafted in the 2026-06-23 chat. Fixes #2 (per-env friction) and #3 (armature/frictionloss) still need host adaptation + cubin build before they're PR-ready. See [[native-cuda-build-pinning]] for the cubin toolchain.

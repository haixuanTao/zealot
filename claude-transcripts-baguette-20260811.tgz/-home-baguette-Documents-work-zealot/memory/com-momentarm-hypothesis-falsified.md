---
name: com-momentarm-hypothesis-falsified
description: "Controlled A/B falsifies the COM-vs-origin contact-jacobian hypothesis for foot-slip; at production iters=2 the foot already sticks, so v56's sim2sim gap is NOT foot-slip."
metadata: 
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

2026-06-23. Hunted the foot-slip / sim2sim gap as a real solver bug (not a knob),
using foot drift_rate (BIPED_DEBUG_CONTACT `[stance]` lines) + critic ΔV as metrics.

HYPOTHESIS TESTED (from a subagent code read, plausible but WRONG): the multibody
contact moment arm uses the link FRAME ORIGIN (`shift_a = pt_world - pose.translation`,
contact_constraints.rs:323) while the body jacobian is COM-referenced (jacobian.rs:4)
and the free-body side uses COM (`free_shift = pt_world - free_mp.com`, :380) — so a
spurious (com−origin)×ω term supposedly made the solver read J·v≈0 (stick) while the
foot slid. FIX = use `mprops.read(colliders_start+id).com` for the mb moment arm.

RESULT — FALSIFIED by controlled A/B (same v56 policy, same cmd, cubin rebuilt both ways):
  drift_rate m/s   iters=2   iters=8   iters=16
  BUGGY (origin)    0.109     0.687     1.811
  FIXED (com)       0.103     0.700     1.819   ← identical within noise
The foot geom is ~5 cm off the link origin (MJCF foot pos="0 -0.035 -0.0385"), so the
moment arm really did change ~5 cm — yet drift was unchanged. So the COM moment arm is
NOT the slip lever. (Fix saved /tmp/fixed_contact_constraints.rs; reverted to canonical.)

implicit_coriolis A/B (runtime knob, current cubin): IC=1 (recompute dynamics/jacobian
per substep) rescues the iters=16 blow-up (IC=0: 7.85 → IC=1: 1.81 m/s) but drift STILL
scales 0.11→0.69→1.8. So the stale per-step jacobian is PART of the high-iters injection,
not the whole substep-scaling. The ∝-substeps energy injection remains unlocalized
(consistent with [[foot-slip-sim2real-gap]]: "resists targeted localization").

KEY REFRAME: at PRODUCTION iters=2 the foot drift is ~0.1 m/s = MuJoCo-like in BOTH
buggy and fixed. The foot ALREADY STICKS at iters=2. Yet v56 (NET+asymDR, trained &
rolled at iters=2) still shows critic ΔV 204% and MuJoCo survival ratio ~0.25
([[critic-value-sim2sim-gap-detector]]). THEREFORE v56's sim2sim gap is NOT foot-slip —
it's some other dynamics difference (force-based PD/motor response, normal-contact
compliance, or an early transient). The substep energy-injection bug is real but only
bites at high iters production doesn't use.

FOOT-ROTATION ("foot rolls when it shouldn't") hunt — ALSO inconclusive at production:
The dramatic rot=33deg that triggered this was at iters=16 (OFF-DISTRIBUTION; v56 trained
at iters=2, the foot spins/flails there) — NOT production. Controlled tests at iters=2:
- capsule vs box foot: rot mean 8.3 vs 7.4 deg — IDENTICAL. Foot shape is NOT the rotation
  driver (capsule-rolling-about-its-axis falsified; box with corners rotates the same).
- NEXUS_CONTACT_SWEEPS 1 vs 8: still exactly 1 normal point loads (mean 1.00) — more PGS
  sweeps do NOT distribute load. The single-point loading is because the foot sits TILTED
  so only one corner is in contact (other generated points have dist>0, impulse 0) — not a
  solve-concentration bug.
- MuJoCo foot rotation per stance (foot_rotation_xval.py, same policy): mean 36 deg (max 60)
  vs nexus ~8 deg — MuJoCo rotates MORE (though confounded: MuJoCo falls in ~1.5s, n=6).
NET: nexus's planted foot is if anything FLATTER than MuJoCo's; no clean evidence of a
foot-roll contact bug at production iters=2. The foot IS effectively single-point-supported
(real under-constraint) but that doesn't manifest as excess rotation vs MuJoCo at iters=2.
Tools added: scripts/foot_rotation_xval.py, critic_divergence.py. Both contact_constraints.rs
fix and the buggy state were A/B'd; repo currently CANONICAL (fix reverted, saved /tmp/fixed_contact_constraints.rs).
Next (still open): the iters=2 sim2sim gap is NOT foot slip/roll — bisect per-step state
(motor/PD response, normal compliance, early transient) for the real divergence.

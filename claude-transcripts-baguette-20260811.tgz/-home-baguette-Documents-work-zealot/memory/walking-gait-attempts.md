---
name: walking-gait-attempts
description: "Walking on zealot biped — failure ladder + foot-contact bug, SOLVED in v32: capsule foot + progress-gated gait + power/symmetry → transferable symmetric walking (MuJoCo 6s, ratio 1.00)."
metadata: 
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

After STANDING was solved (transfers to MuJoCo 6 s, ratio 1.00 — see [[nexus-freefall-dynamics-bug]] explicit force-PD motor, [[nexus-contact-model-realism]], [[limit-riding-and-logstd-collapse]] hip-dev penalty, [[fragile-ankle-hardware]] ankle cap), pushed on WALKING via warm-start from the standing policy + command curriculum (BIPED_STAND_FRAC=0, BIPED_RAMP_END knob added so command ramps to full by ~iter 4500). Run progression v27→v30. Walking is HARDER and not yet cracked.

FAILURE-MODE LADDER (each fix removed one cheat, exposed the next):
- v27 (no gait shaping): tracked velocity by SLIDING the feet (shuffle). Moved 0.17 m/s in nexus but did NOT transfer (MuJoCo 1.2 s, ratio 0.19).
- v28/v29 (gait shaping turned on: air_time 1.5, single_support 1.0, flight -1.0, foot_clearance -1.0, foot_slip -0.5): waddled in permanent DOUBLE-support; gait terms read garbage.
- **FOOT-CONTACT BUG (found + fixed)**: contact was foot-LINK-origin z < CONTACT_Z=0.025, but the link origin rests at ~0.035-0.045 m when the sole is planted → contact NEVER registered → every contact-based gait reward (air_time/single_support/flight/foot_slip/clearance) saw feet as permanently airborne = useless. Fixed: CONTACT_Z → 0.05 (BIPED_CONTACT_Z override). Was harmless while those weights were 0; exposed when gait shaping turned on. Measure foot z from rollout json `frames[:,feet,2]`.
- DOUBLE-SUPPORT PENALTY added (reuses single_support slot: +w single, −w double while moving) → flipped single-support fraction ~1% → ~91% with cook.
- v30 (all the above, full 30k cook): at iter ~6000 it WALKS in nexus — 0.29 m/s fwd @ cmd 0.5, feet lift 1.5-7cm, ~91% single-support. BUT **the full run OVERCOOKED**: by iter 30000 it MARCHES IN PLACE (0.009 m/s) — reward-hacked the single_support/air_time bonuses (they're NOT gated on forward progress), so once it couldn't track the fast command it farmed the stepping bonus by stepping without translating. Best walker = mid-run iter~6000, preserved at /tmp/biped_policy_v30_bestwalker_iter6000.safetensors.

★★★ TRANSFERABLE WALKING ACHIEVED (2026-06-18, v32). The combination closed BOTH problems:
- CAPSULE foot (BIPED_FOOT_SHAPE default capsule): box→capsule so foot-strike ROLLS instead of catching a sharp edge (the divergence diagnostic blamed the ankles at foot-strike; box vs MuJoCo's rounded sole). Single capsule along the foot long axis, radius=half-width, center shifted to preserve sole height. Still learnable (stands).
- PROGRESS-GATED gait bonuses: air_time/single_support bonus ×= clamp((v·cmd)/|cmd|²,0,1) — only paid when actually moving toward command. Kills the march-in-place reward-hack. Double-support penalty stays ungated.
- PRINCIPLED naturalness rewards: mechanical-power penalty Σ|τ·q̇| (BIPED_POWER_W=2e-3, energy/CoT proxy, comp "power") + bilateral_symmetry weight 0→2.0.
RESULT (v32, iter ~1900, cmd 0.5 fwd): walks 0.26 m/s in nexus, SYMMETRIC gait (foot lift 0.038/0.038, sym 1.00, was 0.073/0.013 lopsided), and TRANSFERS — MuJoCo closed-loop survives the full 6s, ratio 1.00 (was 1.5s/0.25 for the box-foot lopsided walker). Open-loop divergence still splits at the ankle ~0.36s but that's the pessimistic open-loop metric (balancing is open-loop-unstable); closed-loop reactive transfer is what matters (same as standing). Frozen: /tmp/v32_frozen.safetensors. Run still cooking (with progress gating it should NOT overcook into marching like v30 did). Pushed: zealot 5e13476 (power+symmetry), ace56f7 (capsule+gated gait).

EARLIER OPEN PROBLEMS (now addressed by the above):
1. REWARD: gait bonuses (air_time, single_support) must be GATED ON FORWARD PROGRESS — only pay stepping reward when the steps move the base toward the commanded velocity — else march-in-place hack. NOT yet implemented.
2. TRANSFER: even the good iter-6000 walker did NOT transfer (MuJoCo 1.5 s, ratio 0.25) while STANDING transfers (6 s). Dynamic gait exposes residual contact-model diffs (single BOX foot vs MuJoCo's 6 rounded sole capsules; contact dynamics at foot-strike/push-off) that don't matter for quasi-static standing. Levers: heavy contact DR during gait (friction/contact-stiffness knobs exist), or match foot contact geometry (engine work).

Knobs: BIPED_RAMP_END, BIPED_CONTACT_Z, BIPED_ANKLE_TORQUE_W. Eval at a forward command: BIPED_RENDER_CMD / BIPED_CMD / BIPED_XVAL_CMD = "0.5,0,0". ALWAYS freeze the checkpoint before dump+xval (trainer overwrites it → net-parity fail).

---
name: native-cuda-build-pinning
description: "Exact dep branches/commits for the zealot native-CUDA build on baguette (5090), cubin rebuild gotchas, and that the trainer plateau is not a dep problem."
metadata: 
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

Native-CUDA (cuda-oxide) build inputs on baguette (RTX 5090, sm_120), verified
2026-06-13 against zealot `docs/native-cuda-4090-test.md` (the authoritative
branch list):
- zealot     feat/native-cuda-e2e-bench  @3ffe35c
- nexus-cuda feat/per-env-parallelism    @7c5cd73 (remote = haixuanTao/nexus-rl, NOT archived nexus-cuda)
- khal       feat/cuda-oxide-profiling   @3f786c2
- vortx      feat/gpu-mdp-kernels        @49fb1a1  (checked out as `master`; master == that branch, same SHA)
- cuda-oxide: NOW FULLY UPSTREAM (khal-std pins git NVlabs/cuda-oxide rev 62472763; all local clones ~/cuda-oxide-{src,main,upstreaming} DELETED 2026-08-05 — untracked autoport example sources archived to ~/Documents/work/autoport-examples-src.tar.gz)
rapier + parry are VENDORED (not git repos) under ~/Documents/work — can't pull, not fetch targets.

CUBIN GOTCHAS (the 4090 port retargeted everything to sm_89 — must undo on this 5090):
- The pulled `build_cuda/build_nexus_cubin.sh` hardcodes sm_89 + /home/peter paths.
  Restore the sm_120/baguette version: `git show 5387b5e^:build_cuda/build_nexus_cubin.sh`.
  Key: system ptxas is CUDA 12.0 (NO sm_120) — must use triton ptxas 12.8 at
  ~/.local/lib/python3.12/site-packages/triton/backends/nvidia/bin/ptxas. LIBDEV =
  ~/nvvm-wheel/.../libdevice.10.bc. TOOL = nightly-2025-08-04 llvm bins; cargo build = +nightly-2026-04-03.
- vortx cubin: use `build_cuda/build_vortx_cubin_only.sh` (libNVVM + ~/make_cubin helper, sm_120) —
  NOT the new build_vortx_cubin_llc.sh (that's the sm_89/4090 llc path). libNVVM works on Blackwell.
- Embed via env: CUDA_OXIDE_SHADERS_PTX_NEXUS_RBD_SHADERS3D + CUDA_OXIDE_SHADERS_PTX_VORTX_SHADERS
  (generic CUDA_OXIDE_SHADERS_PTX injects one cubin into both crates -> "gemm not found").
  To force re-embed after a same-path cubin rebuild: `cargo clean -p vortx` (cargo won't notice content change).
- GOTCHA 2026-06-23 (cost ~30 min): the cubins embed at BUILD time. If you rebuild the example
  with the env vars UNSET — e.g. a routine `cargo build --release --example biped_train_gpu
  --features ...` after a host-only edit — the new binary has NO embedded cubin and panics at
  runtime: `[khal-cuda load_function FAIL] gpu_update_mprops_cuda_entry_<hash> -> CUDA_ERROR_NOT_FOUND`
  at pipeline.rs:968, EVEN THOUGH the cubin file + binary both contain that exact hash (verified
  via `strings`) and setting the var at RUNTIME doesn't fix it (binary strings show "PTX file
  'shaders.ptx' not found in embedded dir"). FIX: always set BOTH env vars during `cargo build`,
  not just at run. Diagnostic: `strings <binary> | grep _cuda_entry` vs `strings <cubin> | grep`.

Two cross-repo build breaks the 4090 session left UNCOMMITTED in khal (had to re-add locally on baguette):
- GpuBackend::is_cuda() was `#[cfg(feature="cuda")]`-only -> added `#[cfg(not(feature="cuda"))]` fallback returning false (pipeline.rs calls it unconditionally).
- CapturedGraph::upload() wrapper (cudarc CudaGraph has .upload(); zealot biped_env_nexus.rs calls graph.upload() but no khal branch had it).

GOTCHA 2026-06-15: `pkill -f biped_train_gpu` between training restarts SILENTLY FAILED several times —
ended up with 5 biped_train_gpu runs concurrently on the GPU (nvidia-smi showed all 5 @3.2GB), so sec/iter
inflated ~5x (v7 hit 19.8s/iter; dropped to 3.2 once the 4 stale ones were `kill -9`'d by explicit PID).
LESSON: after launching a background `&` trainer, verify kills with `nvidia-smi --query-compute-apps` and
kill by explicit PID, not just `pkill -f`. Earlier inflated sec/iter (v4-v6 "~3.3s") were likely contended;
clean full-model (v7) solo = ~3.3s/iter @2048. Also many stale monitor wait-loops linger (watch
"biped_train_gpu 2000") and all fire when the run ends — harmless noise.

The trainer plateau is NOT a dependency problem: with all inputs pinned as above and
both cubins freshly rebuilt for sm_120, biped_train_gpu (200 iters, 2048 envs) gives
reward -4.72->-4.30 (flat), falls ~7500, torso parked ~0.64 — deterministic, byte-identical
before/after the vortx cubin rebuild. Root cause is sim instability (passive_stand collapses,
torso -> -0.36 below floor under PD), upstream of RL. See [[render-path-valid-no-rust-walker]].
The 4090 commit's "trainer learns a locomotion policy" does NOT reproduce on the 5090.

UPDATE 2026-06-13: pulled the maintainer's "fix" commits (zealot a9a7d66 enforce joint
limits + BIPED_FRICTION override; nexus 7368be7 per-env collider friction in contacts
instead of hardcoded 0.5), rebuilt sm_120 nexus cubin (shader DID change, 2299192->2299272 B).
Result UNCHANGED on 5090: final reward -4.27 (was -4.30), falls 7443 (was 7512), torso 0.644.
The joint limits are still the ±π placeholder (per the commit's own comment) so they barely
constrain. Smoking gun: passive_stand torso sinks to mean -0.03 / MIN -0.30 = torso BELOW the
floor (z=0) => foot-ground contact is letting the robot PENETRATE. Likely the real blocker and
where sm_120-vs-sm_89 contact-solver divergence would live. Next: instrument foot-ground contact
generation + penetration under the sm_120 cubin.

UPDATE 2026-06-13 (A/B vs WBC-AGILE): ROOT CAUSE LOCALIZED to the nexus MULTIBODY SOLVER.
- Static config A/B: zealot's robot is a FAITHFUL match to WBC-AGILE
  (~/WBC-AGILE/agile/rl_env/assets/robots/lerobot_humanoid_no_arms.py): kp 30/40/60/60/20,
  kd 3/3/4/4/1.5, effort 88/88/88/88/44, armature hipz .0227 hipx .1333 hipy .1408 knee .1233
  ankle .0299, default_pos 0 — ALL match zealot LeRobotBipedal::family() + motor dump. armature
  applied at full scale (arm_scale=1.0, BIPED_ARM override). NOT a config/gains/pose mismatch.
- Added fast A/B env knobs in biped_env_nexus.rs build_env_scene: BIPED_SOLVER_ITERS / BIPED_CONTACT_NF
  / BIPED_CONTACT_DR (+ existing BIPED_ARM / BIPED_FRICTION). passive_stand (~3s) is the fast probe.
- Sweep result: contact stiffness (BIPED_CONTACT_NF 30->300) = ZERO effect (byte-identical) -> NOT
  soft-contact penetration. BUT increasing BIPED_SOLVER_ITERS INJECTS ENERGY: max torso 0.09(it8)
  ->0.53(it16)->1.12(it24)->4.83(it32). A correct PGS/Gauss-Seidel solver is a contraction (more
  iters converge); this one DIVERGES (pumps energy) => bug in the cooperative Gauss-Seidel PGS apply
  (delta-broadcast + barrier rewrite, see [[multibody-cooperative-rewrite]]) — likely a barrier race
  or double-applied delta. Explains ALL symptoms (can't passive-stand, can't learn, penetration) with
  ONE cause, and fits 4090(sm_89)-learns / 5090(sm_120)-collapses (race resolves per-arch codegen).
- BIPED_IMPLICIT_CORIOLIS is NOT wired into solver.rs (IC=0==IC=1) — that knob from
  [[nexus-solver-cost-knobs]] is stale/removed.
Next: debug the cooperative PGS apply energy-injection (nexus src_rbd_shaders/dynamics/multibody),
or bit-compare sm_120 vs sm_89 solver output on a fixed scene.

CORRECTION 2026-06-13 (MuJoCo A/B — overturns the "sim can't stand = bug" framing):
Built scripts/mujoco_passive_stand.py (loads ~/tmp_eval/mjcf/robot.xml — the WORKING
policy's own model, full meshes incl torso_mesh; per-joint kp/kd/armature = zealot's; PD->all-zero
pose @50Hz/200Hz). RESULT: MuJoCo ALSO FALLS at zero action — a PD-to-all-zero-pose stance is an
inverted pendulum that tips in a KNOWN-GOOD solver too. So passive_stand collapse is EXPECTED
physics, NOT a nexus bug. Earlier "the sim can't hold a stand" was an over-interpretation.
BUT a real fidelity gap remains: apples-to-apples (both UPRIGHT spawn), MuJoCo holds ~0.70 for ~1.0s
then slowly tips (~1.5s); nexus collapses to ~0 by 0.4s — nexus is ~3-4x LESS stable from identical
config. Foot collider ruled out (nexus box = AABB of the real 6 foot capsules, if anything bigger
support polygon). Remaining suspects for faster collapse: the energy-injecting solver (even small
injection at iters=8), contact softness NOT being applied (BIPED_CONTACT_NF was a no-op), or
restitution/damping. STRATEGY SHIFT: the goal isn't passive standing (fails everywhere) — it's
whether nexus is faithful enough for RL to learn an ACTIVE balance like WBC-AGILE's policy did.
The 3-4x faster collapse + iters->energy-injection say nexus has a solver-fidelity problem.

SOLVER DEEP-DIVE 2026-06-13 (both probes done):
#1 WHY BIPED_CONTACT_NF IS A NO-OP (definitive bug): MULTIBODY contacts bypass SimParams entirely.
   gpu_mb_init_contact_constraints (src_rbd_shaders/dynamics/multibody/contact_constraints.rs ~line151)
   receives only dt_uniform, NOT SimParams, and HARDCODES cfm_coeff:0.0, cfm_gain:0.0 (lines ~381/402/
   506/527) + NO ERP/Baumgarte position-correction bias in rhs. RIGID-body contacts do it right
   (solver.rs gpu_solver_init_constraints -> solver_utils.rs contact_to_constraint computes
   contact_cfm_factor/contact_erp_inv_dt from SimParams, sim_params.rs:124-205). So biped feet are
   hard (cfm=0) AND uncorrected (no ERP) -> penetration/slip not fixed. FIX: plumb SimParams into the
   mb contact init kernel + compute rhs bias (erp_inv_dt*pen) and cfm like the rigid path.
#2 WHERE ENERGY IS INJECTED: the individual constraint solves are CORRECT contractions —
   solve_contact_constraints_par (line652) and finalize (line578) compute inv_lhs=1/(J M^-1 J^T) via
   LU of the REAL mass matrix and apply consistent columns=M^-1 J^T; joint solve (line227) likewise.
   Armature IS consistently in M (host adds it to rapier link Izz via additional_mass_properties ->
   from_rapier -> CRBA, same M for dynamics + back-solve) — NOT an inconsistency. Motors are IMPLICIT
   velocity constraints (target_pos in joint solver), not explicit force. So the iters->explosion
   (max 0.09@it8 ->4.83@it32) is real but OFF-DISTRIBUTION (production it8 doesn't explode) and NOT
   yet root-caused (likely hard-contact + bias/stabilization-pass interaction across many sweeps).
ACTIONABLE: #1 is the concrete defect with a clear fix + test (re-run mujoco_passive_stand vs nexus,
then training). The production 3-4x-faster-tip gap is most plausibly the missing contact ERP/CFM.

*** FIX + BREAKTHROUGH 2026-06-13 ***
ROOT CAUSE of the energy injection was in gpu_mb_init_contact_constraints
(src_rbd_shaders/dynamics/multibody/contact_constraints.rs ~line 171): it hardcoded
`erp_inv_dt = inv_dt` i.e. Baumgarte ERP=1.0 (undo ALL contact penetration in ONE step). With
max_corr_velocity=10 m/s, a penetrating foot got a separating bias up to 10 m/s -> LAUNCHED the
articulation. FIX: use the damped Baumgarte from the rigid path, erp_inv_dt = ω/(dt·ω + 2ζ) with
ω = 30Hz·2π, ζ=5 (mirrors SimParams::default; kernel still not SimParams-wired, so hardcoded).
RESULT (passive_stand iters sweep): explosion GONE — max torso 0.09/0.08/0.09/0.10 at it 8/16/24/32
(was 0.09/0.53/1.12/4.83); solver now contractive.
*** This UNLOCKED RL LEARNING. *** biped_train_gpu 200 iters, ERP-fix vs pre-fix baseline:
pre-fix: reward flat -4.72->-4.30, falls RISING 6106->7512 (no learning).
ERP-fix: reward -4.63->-1.25, falls DROPPING 5960->2195 (-70%), inflects ~iter110, STILL improving
at 200. Rendered policy survives ~27 steps (was ~10), doesn't walk forward yet (200 iters << the
33750-iter WBC-AGILE reference). Launched a 2000-iter run (/tmp/biped_policy_long.safetensors,
/tmp/train_long.log). The fix lives in nexus-cuda contact_constraints.rs (UNCOMMITTED) + needs the
sm_120 cubin rebuilt (build_nexus_cubin.sh). Video: /tmp/erp_walk.mp4.
NOTE this also fully explains the original 5090 plateau — it was THIS solver bug all along, not a
sm_120-vs-sm_89 codegen difference (the bug is in shared shader source; WebGPU showed milder
energy injection too). The 4090 "it learns" claim was likely also hampered by the same bug.

2000-ITER RESULT 2026-06-13/14: ERP-fix policy trained to falls 6106->2-3, reward -4.6->+0.14
(positive), curriculum at full velocity. Rendered (illegal-contact disabled): 0 falls in 400 steps
(8s) — STABLE BALANCE, shins at +0.046 (above floor; the 200-iter -0.03 clipping mostly resolved by
more training). BUT travel x~+0.01 — does NOT walk forward despite the 0.4 m/s command. It found a
STAND-STILL local optimum (collects upright/alive reward, ignores velocity-tracking). Next: rebalance
reward toward velocity-tracking / fix the stand-still optimum; that's the walking blocker now, not
the solver. Also: illegal-contact termination (biped_env_nexus.rs illegal_ground_links + BIPED_ILLEGAL_Z,
default 0.06) is too tight — caught the legitimate 0.046 shin; lower to ~0.03 or gate on z<0.01.
Policy: /tmp/biped_policy_long.safetensors. Video: /tmp/long_walk.mp4 (mesh, MUJOCO_GL=egl).

SimParams-WIRING ATTEMPT + DEBUG LESSON 2026-06-14: tried to plumb per-env SimParams into
gpu_mb_init_contact_constraints (new binding set1/b4 + MultibodySolverArgs.sim_params threaded through
solver.rs/pipeline.rs) so contact_natural_frequency/damping DR goes live. It DID make BIPED_CONTACT_NF
live (NF=10 vs 200 differ; were byte-identical before). BUT training appeared to regress (falls->10k).
I misattributed this to the wiring and REVERTED it — WRONG DIAGNOSIS. The real culprit was the
illegal-contact termination I'd added earlier (BIPED_ILLEGAL_Z default 0.06): a trained policy's shins
sit at +0.046, so 0.06 over-terminates every episode, inflating falls and burying the gradient under
the -25 penalty. Confirmed: BIPED_ILLEGAL_Z=-100 (disabled) restored learning identically to erp2.
FIX: lowered BIPED_ILLEGAL_Z default 0.06 -> 0.0 (catch only ACTUAL floor penetration, e.g. the early
-0.03 clipping, not legit low shins). Training now learns AND keeps the anti-clip safety net: 130 iters
reward -4.68->-1.81, falls 6064->3158 (slightly better than disabled). LESSON: when training regresses,
check ALL recently-added env knobs (esp. termination thresholds) before blaming the physics change.
The SimParams contact-DR wiring is currently REVERTED (clean ERP-fix state, contact DR inert). It can be
re-applied cleanly now that the confound is understood — verified it makes the knob live; just needs an
isolated retrain to confirm it doesn't regress (it likely doesn't). State now = ERP fix + illegal@0.0.

SELF-COLLISION 2026-06-14: WBC-AGILE uses THREE mechanisms — enabled_self_collisions=True (PhysX
physical leg-leg) in lerobot_humanoid_no_arms.py:79, PLUS feet_distance + knee_distance terminations
(mdp.link_distance: terminate if the two ankle/knee links are <0.1m apart or >0.5m). nexus CAN'T do
physical self-collision (leg colliders are inert AABB boxes that overlap at rest). Added a distance-
based guard in biped_env_nexus.rs: idx.self_collision_pairs = [(foot,foot_2),(shin,shin_sym),
(tigh,tigh_sym)], terminate if any pair closer than BIPED_SELF_COLL_DIST. DEFAULT OFF (0.0): as a hard
termination WITHOUT physical self-collision it's the ONLY guard, and a from-scratch policy crosses legs
constantly -> falls 6.8k->46k, reward -5->-23, gradient destroyed (same failure class as illegal@0.06).
WBC-AGILE gets away with feet_distance because PhysX physically prevents crossing so it's a rarely-fired
secondary guard. Opt-in via BIPED_SELF_COLL_DIST=0.08 to fine-tune an already-standing policy (trained
minima: feet 0.16/shin 0.12/thigh 0.15). From-scratch-safe alternative = soft reward penalty, not termination.
GENERAL LESSON (3rd time): hard terminations the EARLY policy can't satisfy bury the PPO gradient
(illegal@0.06, self-coll@0.08, WBC-penalty -200 all hit this). Keep them off/loose from scratch.

SELF-COLLISION SOFT PENALTY 2026-06-14 (WORKS): replaced the hard self-collision termination with a
SOFT reward penalty in biped_env_nexus.rs step() par-compute: reward -= sc_weight·Σ_pairs max(0,
sc_margin − dist(L,R))·dt over self_collision_pairs (foot/shin/thigh). Env knobs BIPED_SELF_COLL_DIST
(margin, default 0.12) + BIPED_SELF_COLL_W (weight, default 6.0; 0 disables). Verified: trains normally
(falls 6064->3061, reward -4.68->-1.74 @150 iters — same as no-penalty, NOT buried) AND pushes legs
apart (closest pair, shins, 0.119 -> 0.202; feet/thighs unchanged ~0.15). This is the from-scratch-safe
form the hard termination couldn't be. Policy: /tmp/biped_policy_scsoft.safetensors. Confirms the
soft-penalty pattern is the right fix for all the guards that broke as hard terminations.

TORQUE PENALTY 2026-06-14: zealot had ZERO torque/effort penalty (deliberately omitted, velocity_flat.rs:300
comment — "torque-family: they expose torque obs, we use position PD, leave it out"). So the PD-controlled
robot reward-hacks strained high-torque poses (one-leg balancing at saturated effort) for free. WBC-AGILE's
lerobot config (agile/.../locomotion/lerobot/velocity_env_cfg.py) DOES penalize: joint_torques_l2 base -5e-4
all legs, +-1e-3 ankles, +-5e-3 anklex (ankle-roll), + torque_limits -0.01. Added env-side in biped_env_nexus.rs
par-compute: reconstruct applied PD torque τ=clamp(kp·(q_target−q)−kd·q̇, ±effort) from actions[e]+state+
joints[i], penalize Σ w_i·τ²·dt with those graduated weights. Knob BIPED_TORQUE_W scales the family.
FULL WBC weight (1.0) BREAKS from-scratch learning (falls 6k->12.6k, reward -5.6->-7.9): torque penalty
fights "learn to stand at all" since holding up vs minimizing effort conflict early (same pattern as the
hard terminations). 0.1x learns (falls 6k->4.7k, reward->-2.7, a bit slower than the 3.1k no-penalty).
DEFAULT set to 0.1. Ideal would be a curriculum ramp (0->1 like the velocity curriculum) so it refines
efficiency only after standing is learned. Raise toward 1.0 to fine-tune an already-standing policy.

TORQUE CURRICULUM 2026-06-15: added env.set_torque_scale() + trainer ramp (torque_scale 0->BIPED_TORQUE_MAX
over iters 40%->90%, after standing is learned). Full 2000-iter run with everything on (ERP + illegal@0.0
+ soft self-collision + torque curriculum to MAX=1.0): at iter 800 (torque still ~0) it was NEAR-PERFECT
(reward +0.05, falls 4) — but as torque ramped to full 1.0 the policy REGRESSED back to falling (iter 1999:
reward -4.87, falls 7605; render 50 resets/300 steps). So full WBC torque weight (1.0) is TOO STRONG for
nexus EVEN curriculum'd: the corrective torque nexus needs to stand, squared×WBC-weight, exceeds the
standing reward, so the optimum becomes "collapse to avoid torque cost". WBC tolerates 1.0 because its sim
needs less corrective torque and/or its alive/track rewards are larger. Usable nexus range is ~0.1x (learns,
falls ~4.7k @150). Relaunched 2000-iter with BIPED_TORQUE_MAX=0.1 (/tmp/biped_policy_full01, train_full01.log).
Best clean balancer remains /tmp/biped_policy_long.safetensors (no torque, 0 resets). KEY: nexus's torque-to-
stand is higher than WBC's — a symptom the sim is still less stable/efficient than PhysX; lower torque weights
are the workaround, but it also hints standing in nexus is effortful (worth revisiting solver/PD later).

JOINT LIMITS 2026-06-15 (foot-into-own-shin fix): user saw the foot penetrating its OWN tibia/shin. Cause:
JointSpec.pos_limit was the ±π (±180°) placeholder for ALL joints, so the ankle could over-flex and fold
the foot into the shin (no physical self-collision to stop it). The MJCF the env loads
(RL_policy/robot.xml) has NO range attrs, but the deployment model (tmp_eval/mjcf/robot.xml) + WBC/mjlab
define real ranges: hipz/hipx ±0.349, hipy ±1.047, knee ±0.524, ankley [-0.175,0.349]/[-0.349,0.175] L/R,
anklex ±0.175. FIX (host-side, no cubin rebuild — limits upload via from_rapier): (1) lerobot_bipedal.rs
family() now sets pos_limit per joint to the real (symmetric-magnitude) ranges incl. splitting anklex(±0.175)
vs ankley(±0.349); (2) biped_env_nexus.rs parses the MJCF `range` attr into MjBody.joint_range and prefers
it over the spec when present. Verified: rollout joint angles now clamp to ankley ±0.35 / anklex ±0.18 /
knee ±0.52 / hipy ±1.05 (were ±π). Also flipped biped_render_nexus reset to RANDOMIZED by default
(BIPED_RENDER_DET=1 for the reproducible fixed-template eval) since the user kept seeing no reset variety.
NOTE self-collision soft penalty only covers L/R MIRROR pairs (foot/shin/thigh) — foot↔own-shin is handled
by the joint LIMIT now, but foot↔torso/opposite-leg interpenetration is still unguarded (no physical self-coll).
Launched full corrected run: real limits + ERP + illegal@0.0 + soft self-coll + 0.1x torque curriculum,
2000 iters → /tmp/biped_policy_v2.safetensors, /tmp/train_v2.log.

SELF-COLL PENALTY RETIRED 2026-06-15 (user insight: "max angle is made to avoid collision"): with the
real joint limits in place, measured min L/R link separation is 0.105 m (shins) WITHOUT any self-coll
penalty — well above the ~0.07 crossing threshold. The joint ranges (esp. hipx ±20° ad/abduction) keep
the reachable workspace self-collision-free, so the explicit distance penalty is redundant + competes with
learning. Set BIPED_SELF_COLL_W default 0 (limits handle it; penalty kept as opt-in for foot↔torso etc.).
PERF NOTE: penalty math is NOT the training bottleneck — the ~5x-vs-Isaac gap is the physics engine (~3x
slower than PhysX, and 2048 envs is below nexus's efficient regime) + host-side reward/readback (not fully
GPU-resident). nexus biped_train_gpu @2048: 1.8s/iter learned / 3.3s early; WBC-AGILE Isaac @4096: 0.77s/iter
(~127k env-steps/s vs nexus ~27k); both T=24, 50Hz ctrl/200Hz phys. Current run v4 = limits + ERP + illegal@0.0
+ 0.1x leg torque + full-ankle torque, NO self-coll penalty → /tmp/biped_policy_v4.safetensors, train_v4.log.

---
name: contact-fix-no-transfer-gain
description: "The foot-contact fixes (angular friction / soft contact) fixed the real foot-rock bug and raised nexus reward, but did NOT improve MuJoCo transfer — so the foot contact is not the dominant sim2real gap."
metadata:
  type: project
---

2026-06-23. Closing the contact-realism arc with an honest bottom-line.

We found + fixed a real bug: the single-collider foot rocks/pivots about one contact
point (the "weird sliding-rotating"), via [[foot-pivot-root-cause-single-collider]] and
[[substep-injection-localized-dtinvariant-impulse]]. In-engine fix = angular friction
(condim-style rotational resistance at the single point), ANG_FRICTION_LEN=0.25 cut foot
rotation 8.3°→2.7° at production iters=2.

VALIDATION (v57 = cold 4000-iter retrain on the angular-friction contact, NET + asymDR):
- nexus reward 0.084 (v56) → 0.13 (v57): the flatter foot is EASIER to learn on.
- BUT MuJoCo survival (render_sim2sim, same harness/seed, 400 steps, cmd 0.4):
  v56 reset ~80 steps; v57 reset ~67 steps — v57 transfers SLIGHTLY WORSE.
So fixing the foot-rock did NOT close the sim2real gap. Likely the strong angular friction
made v57 over-rely on a rotationally-locked foot MuJoCo doesn't provide (new mismatch).

CFM soft-contact idea (load-sharing) tested + FALSIFIED for this: at the physical value
nL stayed 1 (single point) — can't share load to box corners that are AIRBORNE (foot
tilted); compliance only redistributes among points already in contact. Load-sharing
needs the foot FLAT (multi-collider patch, blocked by 1-collider assertion) or tilt
resisted (angular friction) — not compliance alone.

CONCLUSION: the foot contact (rock/slip) is NOT the dominant sim2real gap. Consistent with
the earlier fact that at iters=2 the foot drift was already ~MuJoCo-like (0.1 m/s), and the
critic ΔV diverges at 0.06s — BEFORE foot dynamics matter. The gap is the INITIAL response:
force-based PD / motor model fidelity, or a structural model mismatch. NEXT: investigate the
first-few-steps nexus↔MuJoCo divergence in the motor/PD torque response, not the contact.
Cubin state: angfric25 + _pad4 stash backed up at ~/nexus_ptx/*.angfric25.cubin; a CFM
variant at *.cfm.cubin; source currently CFM+angfric0 (contact_constraints.rs).

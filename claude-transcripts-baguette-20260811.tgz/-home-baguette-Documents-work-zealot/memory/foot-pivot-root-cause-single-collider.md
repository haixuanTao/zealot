---
name: foot-pivot-root-cause-single-collider
description: "ROOT CAUSE of the foot 'weird sliding-rotating': nexus enforces ONE collider per body, so the foot is a single shape that contacts at one point under tilt and PIVOTS about it (no rotational constraint). Multi-collider patch fix blocked by a hard engine assertion."
metadata: 
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

2026-06-23. User reframed the sim2sim gap correctly: the planted foot does a coupled
"weird sliding-rotating", not pure slip or pure roll. Traced and root-caused.

QUANTIFIED (biped_render_nexus BIPED_DEBUG_CONTACT, iters=2, v56 policy): per stance,
v_origin / ω = R_eff = 5.1 cm MEDIAN, dead-consistent across 26 stances. That is the
signature of a RIGID PIVOT about a stuck contact point ~5 cm from the foot origin:
- not pure slide (R→∞, v⊥ω) and not spin-in-place (R→0, v→0);
- the contact POINT sticks (Jv_host≈0, solver thinks it's holding) but the foot ROTATES
  about it, so the origin (offset) sweeps. The earlier "foot slides" reading was the
  origin sweeping as the foot pivots.

ROOT CAUSE: only ONE contact point is ever load-bearing. Confirmed it's NOT:
- the COM moment arm ([[com-momentarm-hypothesis-falsified]]),
- the foot SHAPE (capsule rot 8.3° == box 7.4°),
- the PGS sweep count (1 vs 8 → still 1 loaded point),
- (MuJoCo rotates MORE, ~36°, but that's the capsule-trained policy + falling — invalid baseline).
It's that nexus models the foot as a SINGLE collider (MuJoCo uses ~6 sole capsules = a
patch). A single convex shape under any tilt contacts at one point → one point gives ZERO
rotational constraint → the foot screws about it. A real multi-point patch resists rotation.

FIX ATTEMPTED — multi-collider "patch" foot (4 corner spheres on the foot body),
BIPED_FOOT_SHAPE=patch in biped_env_nexus.rs (gated; default still capsule; capacity OK,
MAX_MB_CONTACTS_PER_MB=64). BLOCKED by a HARD engine assertion:
  nexus-cuda src_rbd/pipeline.rs:273  assert_eq!(parent.colliders().len(), 1,
  "Only bodies with exactly one collider are supported.")
The from_rapier pipeline assumes a 1:1 collider↔body mapping (poses, mprops, body_to_link
all indexed that way). So the env's "one collider per body" comment was a REAL engine
constraint, not a simplification. The patch env code is left in place (gated) ready for
when the engine supports it; it panics if opted-in today.

INTRA/PER-SUBSTEP TRACE CONFIRMS THE "DANCE" (2026-06-23, user hypothesis): added a
contact-point world-XY stash into the normal constraint's _pad4 (contact_constraints.rs
~line 417) + trace_foot_substep reports the most-loaded point's cp=(x,y) and nL (#points
bearing load). At iters=1/decim=16 (each pipeline.step = 1 substep), box foot, loaded
foot12: nL=1 EVERY substep (always ONE point), and the foot ORIGIN ox drifts +x
(−0.03978→−0.03903, monotonic) while the contact point cp drifts −x (−0.04495→−0.04566)
— OPPOSITE directions = the foot PITCHES/ROCKS about the single point and ratchets the
origin forward ~0.75mm over ~25 loaded substeps. The contact point also migrates smoothly
(narrow-phase re-picks the deepest point as the foot tilts). Each point's solve is CORRECT
(tJv≈0, sticks) — there's no per-point slip bug; the forward drift is purely the
single-point geometry letting the foot rock. So the fix is NOT in any per-point solve; it
is STRUCTURAL (need a patch). The dt'-invariant impulse ([[substep-injection-localized-dtinvariant-impulse]])
is what feeds the rock per-substep, but the drift mechanism is the single-point rock itself.

TWO REAL FIX PATHS (both nexus engine work, user's call on scope):
(a) Lift the one-collider limit → allow N colliders per body throughout from_rapier +
    the contact/pose/mprops pipeline. Bigger (pipeline-wide), enables a true sole patch.
(b) Add TORSIONAL + ROLLING contact friction (MuJoCo condim=4/6 analog) to
    contact_constraints.rs so a SINGLE point resists rotation about the normal/tangents.
    More contained (cubin rebuild), directly opposes the measured pivot.
Tools: critic_divergence.py, foot_rotation_xval.py, the [stance] R_eff pivot test.

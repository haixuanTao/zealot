---
name: render-path-valid-no-rust-walker
description: "biped_render_nexus IS policy-valid (earlier \"invariant\" bug was stale-binary); no rust safetensors walks — only PyTorch/Isaac policy_33750.pt does."
metadata: 
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

`biped_render_nexus` render/eval path is VALID — actions reach the physics motors.
Proven via BIPED_FORCE_ACT diagnostic (force ±v oscillation on env 0, bypassing
policy → rollout md5 changes) and two different policies producing different
rollouts. The earlier "two policies → byte-identical rollout md5 f1fc5e1e"
finding was a stale-binary / reused-output-file artifact, NOT a real bug. Do not
re-chase a "policy-invariant render" phantom.

No working WALKING policy exists in the zealot rust pipeline as of 2026-06-11.
Both `/tmp/biped_policy_nexus.safetensors` (md5 91176d4b) and
`/tmp/biped_policy_baguette.safetensors` (md5 f981cd0b) COLLAPSE: base height
sags monotonically 0.72→0.40 over ~10 steps, fall-termination fires, reset,
repeat. Net forward progress ≈0. They are early/diverged training artifacts.

The only genuinely-working walker on baguette is the SEPARATE PyTorch/Isaac
policy `/home/baguette/tmp_eval/policy_33750.pt` (+ walk.mp4, 33750 iters) — a
different mature pipeline, NOT zealot. See [[tier2-gpu-resident-rollout-not-worth-it]]
for the perf side. Getting zealot's rust PPO to actually walk is still open
(needs grad clipping + reward tuning; advantage-norm + log_std clamp already added).

Build note: khal `GpuBackend::is_cuda()` was cuda-feature-gated; added a
`#[cfg(not(feature="cuda"))]` fallback returning false so pipeline.rs's
fixed-grid-default call compiles under WebGPU-only (biped_gpu,gpu) builds.

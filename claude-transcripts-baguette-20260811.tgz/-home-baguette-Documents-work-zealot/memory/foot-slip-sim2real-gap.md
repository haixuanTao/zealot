---
name: foot-slip-sim2real-gap
description: "The real sim-to-real gap — nexus articulated contact friction doesn't enforce stick under load; feet slide where MuJoCo's stick. Confirmed by sim2sim drift comparison."
metadata: 
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

The biped's "feet sliding while in contact" (and the chronic MuJoCo transfer
failure) is a **nexus contact-solver fidelity defect**, NOT a gait/reward issue.

**Measured (same v51 policy, cmd 0.4 m/s, both engines):**
- nexus loaded-foot drift 0.5–2.0 m/s; stance lasts ~0.02s (ONE control step —
  the foot never plants); even rare longer stances drift ~0.25 m/s.
- MuJoCo loaded-foot drift mean 0.13 / median 0.10 m/s; stance 0.1–0.4s (real
  plant); committed stances drift 0.03–0.09 m/s. The foot STICKS.
- Survival: nexus 12s vs MuJoCo 5.86s (ratio 0.49 → harness verdict "MuJoCo
  falls MUCH FASTER, policy exploits nexus-specific dynamics"). MuJoCo moonwalks
  backward −4.5m and falls.

**Non-physical signature (the smoking gun):** on a loaded nexus foot the applied
tangent friction `F ≈ 0.015` sits FAR below the cone clamp `μN ≈ 0.10–0.17`
(stick regime) WHILE the foot slides up to 2 m/s (slip regime). Coulomb friction
forbids both at once: slip ⟺ F saturated at μN; F<μN ⟺ zero slip. So the
articulated tangent constraint isn't coupled to the foot's true Cartesian motion
— it drives its own generalized-velocity slip estimate to ~0 cheaply, declares
stick, leaves 85% of friction budget unused, and the foot (dragged by the stiff
kp×4 leg motors solved around the contact + base rotation) slides anyway.
`rb_vels` also reports the foot slow (~0.05 m/s) while position-FD shows 2 m/s —
same decoupling. NOTE: "more contact sweeps" (NEXUS_CONTACT_SWEEPS) only moved
0.3→0.27 m/s, it plateaus → it's a coupling/solve-order defect, not iteration count.

**Wrong turns (don't repeat):** rb_vels-based v_contact≈0.02 "ankle rock/rolling"
was WRONG — ruled out because ω·R (~0.06 m/s) ≪ translation (2 m/s); user was
right "rolling makes no sense / speed doesn't match rotation". The DECISIVE
measurement is raw world-position finite-difference of the loaded foot origin
(no velocity convention), per-stance-phase. Both debug readouts are gated:
nexus `BIPED_DEBUG_CONTACT=1` in biped_env_nexus.rs debug_contact_impulses()
(prints [contact] F/Jv(rhs), [stance] drift, root_lin/ang + max|q̇|); MuJoCo
`BIPED_FORCE_PHASE3=1` in sim2sim_xval.py phase3 (prints [stance] drift + summary).

Solver order (nexus apply_substep, multibody.rs ~1895): integrate v → solve
joint MOTORS (with bias) → init/finalize/solve contact → integrate positions →
motor stabilization (no bias) → contact stabilization. Motors-as-constraints +
kp×4 stiffness overpower the interleaved contact friction.

**CORRECTED 2026-06 (term-by-term CRBA audit):** NOT a g/M / free-fall dynamics
bug. In TRUE contact-free free-fall (BIPED_FREEFALL_Z=2.0 BIPED_PASSIVE=1) the
generalized accel is EXACTLY pure free-fall: a_base=[0,0,-9.81 | 0,0,0],
a_joints=all 0.0. So CRBA gravity/mass-matrix dynamics ARE consistent (equivalence
principle holds to precision); task #27's old spurious-accel was the MOTOR MODEL,
already fixed. The large pre-contact `a` (knee +48, base ωy +7) seen in PASSIVE
STANDING is PHYSICAL gravity loading through ground contact (foot N>0 at step 1),
NOT a bug — I mis-attributed it. The drift ∝ substeps is therefore a CONTACT-SOLVER
substep-scaling interaction, not the passive dynamics. Prime remaining suspect: the
speculative-contact normal rhs `dist·inv_dt` (inv_dt=N/dt scales with substeps,
contact_constraints.rs:330) and/or per-substep normal→tangent coupling. Diagnostic
flags: BIPED_FREEFALL_Z (lift for free-fall test), BIPED_IMPLICIT_CORIOLIS,
BIPED_SOLVER_ITERS, BIPED_DEBUG_CONTACT (a_base/a_joints + stance drift + Jv_host/|J|).

**INVESTIGATION OUTCOME (exhaustive, 2026-06):** Pinned the MECHANISM, not a single
line. Drift ∝ total physics substeps/control-step (≡ inv_dt; iters=2 ≈ MuJoCo,
robot stable, drift 0.1cm-ish; iters=16 ≈ 3× MuJoCo). Per-substep NORMAL contact
impulse is dt-INVARIANT (~0.06/slot at iters 2 AND 16) when it must be ∝dt' →
total support ∝ substeps → at iters=2 robot sinks slightly (z 0.66), at iters=16
over-supported. Support comes from the SATURATED erp position-correction bias
(erp_inv_dt = ang_freq/(dt·ang_freq+2ζ) → const as dt→0), not gravity-cancellation;
cfm_gain=0, end-of-step jv≈0 (foot held, momentum-neutral in NORMAL dir). Best
remaining theory: the per-substep normal bias couples into TANGENTIAL motion via
M⁻¹ and leaves a residual the stabilization doesn't strip → ∝substeps tangential
drift. RULED OUT (all tested, all clean): (1) motor stiffness [force-PD in
gen_forces, soft kp still slides]; (2) contact jacobian [|J|≈1.3 healthy, swing-foot
Jv correct]; (3) finalize columns [col=M⁻¹Jᵀ, inv_lhs=1/(J·M⁻¹Jᵀ) correct]; (4) g/M
dynamics [BIPED_FREEFALL_Z=2: a = pure free-fall to precision]; (5) manifold
staleness/refresh-rate [BIPED_DECIMATION deconfound: 4×8 ≈ 8×4 at fixed total
substeps]; (6) speculative dist·inv_dt [=0 for loaded feet]; (7) erp bias [saturates,
=0 post-strip for loaded feet]; (8) incomplete stabilization [NEXUS_CONTACT_STAB_SWEEPS=8
no change]. NEXT (durable fix): in-solver MID-SUBSTEP probe (shader stash + cubin
rebuild, OR break solve_tgs encoder pass per substep) to catch the per-substep
tangential residual — host-side end-of-step probing is exhausted (everything reads
clean). Diagnostic knobs (all default no-op): BIPED_FREEFALL_Z, BIPED_DECIMATION,
BIPED_IMPLICIT_CORIOLIS, BIPED_SOLVER_ITERS, NEXUS_CONTACT_STAB_SWEEPS,
NEXUS_CONTACT_SWEEPS, BIPED_DEBUG_CONTACT (a_base/a_joints + per-foot stance drift +
Jv_host/|J| + normal jv/cfm_gain). Pragmatic near-term: train at low substeps
(matches MuJoCo) — but user flagged that as unrealistic (masks, sacrifices accuracy).

**RAPIER CROSS-CHECK (2026-06):** Single rigid foot box in rapier CPU = rock-stable,
NO slide → rapier's rigid contact is clean; the slide is in the multibody path.
Tried running v51 closed-loop in rapier CPU (biped_render + biped_env, --features cpu):
needed (a) explicit-PD actuator [BIPED_EXPLICIT_PD=1 — rapier's stock constraint
ForceBased/AccelerationBased motors BUCKLE this robot, the nexus explicit-PD-in-solver
is why nexus stands], (b) gait clock [biped_env had `phase: 0.0` hardcoded — added
gait_phase advance], (c) lag-2 last_action [biped_env was lag-1; nexus/policy = lag-2].
After all three: step-0 obs is BIT-IDENTICAL to the nexus dump (all 45 dims), so obs
convention is CORRECT — yet the policy still TIPS in 0.18s (vs MuJoCo 5.86s, nexus 12s).
→ GENUINE DYNAMICS DIVERGENCE: nexus has diverged so far from stock rapier (motor model
+ multibody contact substep) that its policy transfers WORSE to rapier (0.18s) than to
MuJoCo (5.86s), despite nexus being a rapier GPU port. Foot-slide can't be measured
closed-loop on rapier (no stable stance). Knobs added: BIPED_EXPLICIT_PD, BIPED_GAIT_PERIOD,
BIPED_DUMP_OBS0 (biped_render/biped_env); biped_smoke_cpu got BIPED_SOLVER_ITERS/KP_SCALE
+ AccelerationBased default + URDF symlink at ~/Documents/work/lerobot-humanoid-design/urdf/...

**CHARACTERIZED via in-solver cubin probe (2026-06) — energy injection grows with substeps.**
Stashed the contact solve's pre-impulse J·v into MultibodyContactConstraint._pad0
(with-bias) / _pad1 (no-bias) in solve_contact_constraints_par; read host-side. The
foot's normal contact velocity GROWS with substeps (iters2 |Jv|≈0.003, iters16≈0.05 —
should be ∝dt' i.e. ~8x SMALLER) = non-conservative ENERGY INJECTION in the multibody
substep contact loop. **WARMSTART IS NOT THE FIX (verified by reasoning, NOT implemented):**
rigid-body warmstart (solver.rs:358) works because rigid solver_vels are RESET each substep,
so re-applying the accumulated impulse is correct. The multibody dof_state PERSISTS across
substeps (each solve delta integrates into it and stays), so the prior substep's impulse is
ALREADY in dof_state — warmstarting would DOUBLE-COUNT (inject MORE energy). That's why the
prior warmstart attempt was reverted CORRECTLY. Re-zeroing the impulse each substep
(init_contact impulse:0.0) IS correct for persistent-velocity multibody. So the energy
injection is NOT the impulse handling — it's elsewhere in the bias / no-bias-stabilization /
position-integration interaction across substeps (STILL UNPINNED after ruling out: warmstart,
erp magnitude [NF/DR insensitive], extra stab sweeps [no-op], dynamics [free-fall exact],
jacobian [|J| healthy], finalize columns [correct]). ACCEPTANCE for any real fix: solveJv ∝
dt', drift substep-invariant, robot stands, free-fall stays exact. CUBIN TOOLCHAIN WORKS
(~15s/cycle): ~/build_nexus_cubin_libnvvm.sh then rebuild zealot example with
CUDA_OXIDE_SHADERS_PTX=$HOME/nexus_ptx/nexus_rbd_shaders3d.cubin. Probe still in _pad0/_pad1
of solve_contact_constraints_par (REMOVE before any real change). This is deep nexus-core
solver work needing a conservative substep-contact redesign; see [[nexus-freefall-dynamics-bug]].

**SLIDE = SLOW TOUCHDOWN-ARREST (per-pipeline-step trace, 2026-06).** The foot does NOT
spontaneously slide while planted — it LANDS moving (~0.3 m/s horizontal) and the contact
takes ~5 pipeline-steps (~25ms ≈ 40 substeps at iters=8) to arrest it, sliding (vH 0.2–0.4,
N up to 0.13) the whole time; MuJoCo arrests a hot-landing foot in ~1 step. So the energy
injection (∝substeps) is WHY the arrest is slow: each substep the contact should bleed the
foot's tangential velocity but it keeps getting re-fed, so arrest takes ~40 substeps not ~8;
more substeps → more re-injection per arrest → longer slide. Exact onset = the touchdown
substep. Trace tool: BIPED_SUBSTEP_TRACE=1 (per-pipeline-step foot xy+N readback in the
non-graph decimation loop of biped_env_nexus.rs step(), method trace_foot_substep) — run
WALKING (active policy, not passive; the slide is at touchdown transients, passive standing
barely creeps) at native decim4/iters8. NOTE: Phase-A iters=1/high-decim does NOT reproduce
(decim32 → sim_dt 0.0006 → foot barely loaded N≈0.006, no slide); faithful trace needs native
iters=8 → only per-pipeline-step (4/ctrl-step) host-side; per-SUBSTEP + per-OPERATION needs
the Phase-B cubin probe. NEXT (Phase B): trace substep-by-substep through the touchdown
pipeline.step whether each contact solve reduces vs re-injects the tangential velocity.

**FIX VALIDATED via iters=2 retrain (v52, 2026-06).** Trained at BIPED_SOLVER_ITERS=2
(faithful regime where the substep energy injection is negligible), 300 iters warm-
started from v51 (/tmp/v52_iters2.safetensors). RESULT: foot STICKS in both engines —
v52 nexus drift 0.107 m/s (vs v51 0.5–2.0 sliding), MuJoCo drift 0.10. And v52 WALKS
FORWARD in MuJoCo at +0.44 m/s (matches 0.4 cmd) where v51 moonwalked BACKWARD −4.5m.
So the gait BEHAVIOR now transfers (direction+speed+planted feet) = the foot-slip
sim-to-real gap is closed at the dynamics level by training in the faithful regime.
NOT YET ROBUST: v52 MuJoCo survival only 2.10s (vs v51 5.86s) — but v52 is just 300
warm-start iters (vs v51 = many runs) and had to unlearn v51's slide-exploiting
backward shuffle; reward still climbing / falls still dropping at iter 299. NEXT for
robustness: more iters (ideally fresh-from-scratch at iters=2, not warm-started from
the wrong-dynamics v51) + push/DR terms. Trainer: BIPED_SOLVER_ITERS=2
biped_train_nexus <iters> <num_envs> <path> (--features "gpu biped_gpu cuda_backend",
CUDA_OXIDE_SHADERS_PTX=canonical cubin; ~9s/iter, CPU policy+PPO bound). The deep
multibody-contact-substep solver fix remains the durable alternative to iters=2.

**v53 (iters=2 + push DR, 500 iters warm from v52, /tmp/v53_robust.safetensors):** foot
STICKS both engines (nexus 0.104, MuJoCo 0.12), walks FORWARD +1.80m @ 0.76 m/s in MuJoCo
(v52 +0.93m@0.44; v51 backward). BUT MuJoCo survival only 2.38s (v52 2.10, v51 5.86) — push
robustness improved the forward gait but did NOT close the survival gap. CONCLUSION: the
foot-slip was ONE component of the sim2real gap (now FIXED via iters=2), NOT the whole thing —
a RESIDUAL sim-to-sim difference still tips the robot ~2.4s in MuJoCo (suspects: contact
stiffness/integration details; or over-driving — v53 walks 0.76 vs cmd 0.4). NEXT for full
transfer: tighter command-tracking + contact-stiffness DR, more iters, possibly address other
nexus-vs-MuJoCo dynamics. SOLVER FIX (option 2): every targeted hypothesis ELIMINATED (coriolis
off→worse, bias NF=0→no change, friction small, foot-shape neutral, warmstart double-counts,
stab-sweeps no help, free-fall exact) → it's a ground-up energy-conserving multibody-contact-
substep reimplementation (rigid-body path's scheme ported), a research task, NOT a targeted edit.
Acceptance for any such fix: per-substep normal impulse ∝dt' (currently dt-invariant), drift
substep-invariant, free-fall stays exact, robot stands. Next concrete step if pursued: directly
measure KE+PE per substep (cubin) to localize the non-conservation.

**OBSERVED — drift scales with num_solver_iterations (substeps):**
iters=2 → 0.11 m/s (MATCHES MuJoCo 0.10), 4 → 0.36, 8 (training default
SOLVER_ITERS) → 0.70, 16 → 3.05, 32 → 2.50. Robot stays stable (z 0.66–0.72, no
fall) at ALL iters. So a per-substep velocity is injected at full magnitude
instead of scaled by dt'=dt/N — same family as the open spurious-joint-accel /
g-M inconsistency (task #27). NOT the contact friction itself: the tangent
jacobian is healthy (|J|≈1.3, same as swing foot) and the solve DOES drive
Jv_host=jac·dof_state→0 by end-of-step; the foot slid DURING the step from a
mis-scaled per-substep accel. Ruled out: motor stiffness (force-based motors are
applied as gen_force PD in gpu_mb_gravity_and_lu, NOT velocity constraints — see
joint_constraints.rs:743 early-return; soft kp still slid 0.7 at iters=8), contact
sweeps (plateau), contact jacobian/columns (finalize math correct: col=M⁻¹Jᵀ,
inv_lhs=1/(J·M⁻¹Jᵀ)).

TWO FIXES: (a) PROPER — fix the dt term in the per-substep dynamics kernel
(gpu_mb_gravity_and_lu / integrate path), cubin rebuild, resolves task #27 too;
exact line not yet pinned. (b) PRACTICAL/VALIDATED — train at SOLVER_ITERS=2
(BIPED_SOLVER_ITERS=2, or const SOLVER_ITERS in biped_env_nexus.rs:46), where
nexus contact already matches MuJoCo; needs a retrain (current policies trained
at 8). See [[nexus-freefall-dynamics-bug]] (task #27),
[[nexus-contact-model-realism]], [[force-motor-16x-underrealized-stiffness]],
[[render-path-valid-no-rust-walker]], [[walking-gait-attempts]].

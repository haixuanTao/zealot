---
name: sim2real-gap-hipz-dynamics
description: "The real sim2real gap is a ~6× one-step motor/dynamics divergence in hipz (hip-yaw) — nexus accelerates it 6× less than MuJoCo for the same state+action+gains; effective inertia too high (joint-axis/M bug, task #27), NOT the foot contact."
metadata:
  type: project
---

2026-06-23. After the contact arc was a dead end for transfer
([[contact-fix-no-transfer-gain.md]]), built scripts/motor_step_compare.py:
a CUBIN-FREE one-step bisection. For each step t of a nexus rollout (state, action,
state[t+1] all from the rollout's base/joints/obs), set MuJoCo to the EXACT nexus
state (incl. base lin+ang vel by finite diff) + same PD target, step ONE control
step, compare per-joint Δq̇ to nexus's own (obs[t+1]−obs[t]). Gravity exact + (in
flight) no contact ⇒ isolates motor/PD torque + articulated dynamics (M).

RESULT (298 steps, |Δq̇ err| rad/s/step, vs v56 rollout):
  hipz_left   9.09   (nexus|Δq̇| 1.57  vs  mujoco 9.74,  mj|τ| 33)
  hipz_right  8.92   (1.51 vs 9.63, τ 39)
  ankley_R    4.60   (1.37 vs 5.34)
  ankley_L    3.08   (1.32 vs 3.74)
  hipx ~1.3, anklex ~1.0, hipy/knee ~0.9   (these AGREE: err ≈ Δq̇ magnitude)
mean rel err 132%. So most joints match; hipz blows up 6× and ankley 4×.
NOT a harness artifact: adding base angular velocity changed nothing; MuJoCo model
keeps robot.xml damping/frictionloss/armature + same gains (kp×4/kd×2). PD torque is
deterministic (both ≈33 N·m) ⇒ 6× less accel = ~6× too much EFFECTIVE INERTIA on the
hipz DOF in nexus.

LEADING HYPOTHESIS: hipz = hip-YAW, should spin the leg about its ~vertical LONG axis
(small inertia). If nexus's hipz joint AXIS is misaligned (rotates the leg about a
perpendicular axis), it sees ~6× the inertia → sluggish. Matches task #27 (g/M
inconsistency / spurious joint accel). nexus uses JointAxis::AngZ for the revolute;
check the joint local frame / axis orientation vs the MJCF joint axis for hipz (and
ankley). This — NOT the foot contact — is the transfer gap: policy learns to over-drive
a sluggish hipz in nexus, then it over-responds in MuJoCo → falls.
NEXT: verify hipz/ankley joint axis + effective inertia (read the per-DOF M diagonal or
the joint axis from build_env_scene vs the MJCF) and fix the misalignment/inertia.
Tool: scripts/motor_step_compare.py (cubin-free, reusable).

UPDATE — name≠axis (user) + MuJoCo M/axis grounded. ALL MJCF joints are axis="0 0 1"
(local Z); the anatomical name comes from the BODY QUATERNION orienting local-Z in the
world. MuJoCo eff inertia (mj_fullM diag) + world axis at a pose:
  hipz 0.044 axis~(0,.14,.99) VERTICAL (lowest I); hipx 0.15 ~Z; hipy 0.33 (0,1,0) lateral;
  knee 0.14 (0,1,0); ankley 0.030 (0,1,0); anklex 0.030 (1,0,0).
nexus accelerates hipz 6.5× less ⇒ nexus eff hipz inertia ≈ 0.044×6.5 ≈ 0.29 — matching
hipy's 0.33 (the HIGH-inertia LATERAL axis). So nexus's hipz behaves as if rotating about a
lateral axis, not the vertical one ⇒ the hipz (and ankley) JOINT-FRAME ORIENTATION is wrong
in nexus (local-Z points the wrong world direction), giving ~6× the inertia. That is the
transfer gap (task #27 g/M), NOT contact. FIX: correct the per-joint frame orientation
(local_quat / kinematic-chain) so AngZ lands on the MJCF world axis; verify by comparing
nexus mass_matrices diag for hipz/ankley to MuJoCo's 0.044/0.030.

*** ROOT CAUSE FOUND 2026-06-23 *** Compared nexus links_mprops vs MuJoCo body_mass/
body_inertia per leg link (debug_joint_axes dumps nexus; /tmp/mj_bodyI.py dumps MuJoCo):
  link    MuJoCo mass / nexus mass    MuJoCo principal I / nexus principal I
  hipz    1.058 / 0.794   (.0014,.0012,.0010)/(.0007,.0010,.0012)
  hipx    0.452 / 0.242   (.0009,.0008,.0008)/(.0004,.0005,.0005)
  hipy    2.606 / 2.580   (.025,.024,.004)/(.004,.023,.024)  <- small-I axis 3 vs 1
  knee    0.637 / 0.593   (.0018,.0018,.0003)/(.0002,.0017,.0018) <- permuted
  ankley  0.033 / 0.017 ; anklex 0.122/0.122 (match)
TWO bugs in nexus's MJCF→link mass-property conversion (= the task #27 g/M inconsistency):
1) MASS wrong & non-uniform (hipx 54%, ankley 51%, hipz 75% of MuJoCo) — NOT mass DR
   (DR is one scale for all links; these ratios differ). nexus derives link mass
   differently from the MJCF <inertial>.
2) INERTIA TENSOR MIS-ORIENTED: principal eigenvalues match as a SET but assigned to
   different axes (hipy/knee small-I on axis 3 in MuJoCo, axis 1 in nexus) ⇒ the tensor
   is rotated/permuted. This makes the ARTICULATED inertia about hipz (hip-yaw, vertical)
   pick up the wrong large component ⇒ hipz eff inertia 6× too high ⇒ the one-step Δq̇
   gap ⇒ the SIM2REAL TRANSFER GAP. (Mass being LOWER would make it faster, so the
   inertia mis-orientation dominates.)
NOT contact, NOT the PD formula — the MASS-MATRIX INPUTS. FIX: correct build_env_scene's
link mass+inertia (parse the MJCF <inertial> mass + orient the inertia tensor / ref_frame
to match), then re-run motor_step_compare.py (success = hipz/ankley err drop to ~1× like
the others). Caveat: confirm the inertia mis-orientation with the full world tensor
(ref_frame·diag(I)·ref_frameᵀ) — the principal-value permutation alone could be benign if
ref_frame compensates; but the mass error + 6× eff-inertia are independently solid.

*** CORRECTION 2026-06-23 (the "wrong masses" claim above is RETRACTED) ***
The per-link mass/inertia comparison was confounded by a JOINT-vs-BODY NAMING OFFSET:
MuJoCo joint "hipz_left" lives in body 'hipx_subassemby_sym' (mass 1.058), "hipx" in
'hipy_subassembly_sym', etc. — so my nexus-hipz-link (0.794) vs MuJoCo-hipz-joint-body
(1.058) compared DIFFERENT bodies. TOTAL mass is 12.72 kg in BOTH; nexus reads every
robot.xml <inertial> mass correctly, and build_mujoco_model is faithful (inertiafromgeom
=false, total 12.72 not the geom-inflated 20.3). So nexus's link mass INPUTS are RIGHT.
STILL SOLID: the one-step Δq̇ divergence (motor_step_compare) hipz 6× / ankley 4×, SAME
DOF by name, SELECTIVE (others ~1× — rules out a global units/convention bug). So with
correct mass inputs on both sides, nexus's hipz/ankley EFFECTIVE inertia is still 6×/4×
off ⇒ the bug is in nexus's MASS-MATRIX / articulated-inertia (CRBA) COMPUTATION or the
joint axis used inside it, for those joints — NOT the mass inputs. (Two prior leads —
contact, link-masses — did not hold; the one-step localization is the robust thread.)
CLEAN NEXT STEP: get nexus's actual M[hipz_dof] diagonal (add mass_matrices accessor;
handle the in-place LU by reading M right after the mass_matrix kernel / before lu, or
reconstruct M=L·U from the factored buffer+pivots) and compare to MuJoCo mj_fullM 0.046.
Also re-verify motor_step_compare's joint_vel convention isn't a per-joint sign artifact.

*** RESOLVED 2026-06-23 — nexus M IS CORRECT; the 6× was a harness artifact ***
Added mass_matrices()/lu_pivots() accessors, dumped env0's mass-matrix LU AFTER a step
(dump_mass_matrix → /tmp/nexus_M.json), reconstructed M (recon_M.py). nexus M diagonal vs
MuJoCo mj_fullM (same spawn pose), ALL joints within ~5%:
  hipz 0.044/0.046  hipx 0.145/0.147  hipy 0.324/0.337  knee 0.139/0.141  ankley 0.030/0.030
(joint-DOF block needs no pivoting → diagonal trustworthy despite imperfect root-block
unpermute; ratios match too: hipz/knee 0.32 vs 0.33). So nexus's hipz inertia = 0.044, NOT
the inferred 0.29 — NO 6× inertia/CRBA bug. The motor_step_compare "hipz 6× / ankley 4×"
one-step Δq̇ was a HARNESS ARTIFACT (its Δq̇-from-obs has a joint_vel convention problem —
the SAME ~1.5 rad/s joint_vel discrepancy that breaks sim2sim_xval phase-2).
NET (3 collapsed leads): the sim2real gap is NOT contact (no transfer gain), NOT link mass
(read correctly), NOT mass matrix/CRBA (matches MuJoCo). nexus rigid-body dynamics look
CORRECT vs MuJoCo. The recurring signal pointing somewhere NEW: the joint_vel obs
discrepancy (~1.5 rad/s) → suspect the OBSERVATION pipeline / lag conventions (policy sees
different obs in nexus-train vs MuJoCo-deploy), not the physics. motor_step_compare.py is
UNRELIABLE (convention bug) — fix or distrust it. NEXT: diff the obs construction (esp.
joint_vel + last_action lag + gait phase) between the nexus env and sim2sim_xval/deploy.

*** joint_vel obs-convention lead ALSO negative (2026-06-23) ***
nexus trains obs joint_vel = finite-diff (q-q_prev)/control_dt (biped_env_nexus.rs:915);
render_sim2sim deploys INSTANTANEOUS data.qvel (render_sim2sim_mujoco.py:111). Added
BIPED_JVEL_FD to make sim2sim use finite-diff (match training). v56 MuJoCo survival:
instantaneous 80 steps vs finite-diff 67 steps — NOT better. So the joint_vel convention
isn't the transfer gap either. (It WAS the motor_step_compare artifact: finite-diff/avg
vel vs instantaneous — so motor_step_compare is confirmed unreliable.)
CONSOLIDATED: sim2real gap is RULED OUT for contact, link mass, mass matrix/inertia,
joint_vel obs. nexus physics is faithful to MuJoCo where measured. ~5 leads collapsed.
Remaining (qualitatively different, unpinned): chaotic/accumulated trajectory divergence
(no single cause), or POLICY FRAGILITY (v56 robust in nexus-deterministic but not under
MuJoCo perturbed restarts → fix = training robustness/DR, not a sim bug), or closed-loop
interaction. RECOMMENDATION: stop single-cause physics hunt (diminishing returns); either
(a) accept nexus is faithful + train for robustness, or (b) test policy-fragility framing
(does v56 fall in NEXUS too under the same perturbed restarts render_sim2sim uses?).

v28 G1 sim2sim status (2026-08-06, CAVEATED): v28 @ iter 31350 survives a
full 20 s MuJoCo rollout traveling 8.70 m (iter 12300: 20 s / 7.90 m) —
SINGLE attempt each, one command profile, so the 12k→31k travel delta is
suggestive, not established. IMPORTANT SCOPE NOTE: the v56–v58 ~1.4 s
survival numbers in this memory family are the LEROBOT bipedal, a different
robot — the G1 line transferred acceptably since at least v19 (the website
MuJoCo-wasm demo walks v19). Don't cite v56-era numbers as a G1 baseline.
Released anyway (transfer robustness is real): HF velocity_v28_iter31350 +
GH tag checkpoints-2026-08-06-v28-iter31350 (with the eval mp4).

v28 CONCLUDED (2026-08-06, 50k iters/35 h): final pick = ITER 44000 via a
3-command MuJoCo sweep (44k/47k/50k, all 20 s survival) — smoothest knee at
every command (>5 Hz power 17.6/4.4/18.9% at 0.4/0.7/turn) AND fastest at
speed (12.25 m @0.7 cmd). Key lessons: (1) tremor bottoms mid-run (44k) and
REGRESSES after — select checkpoints by measured tremor+transfer (S2S_TRACE),
never recency; (2) chatter concentrates at SLOW speeds (quasi-static balance),
teleop's home regime; (3) the training reward can't see either effect.
Released: HF velocity_v28_iter44000 (RECOMMENDED on card) + GH tag
checkpoints-2026-08-06-v28-iter44000-final. v29 launched same night on bare
defaults (knee W_TORQUES 1e-4, tremor W_ACTION_RATE_RATE -0.3, master +
nexus feat/browser-web-demo + O3 cubins) → ~/overnight/g1_v29.safetensors,
train_v29.log. Success criteria: knee ROM past 0.30 rad, terrain >13,
knee >5 Hz power <5%.

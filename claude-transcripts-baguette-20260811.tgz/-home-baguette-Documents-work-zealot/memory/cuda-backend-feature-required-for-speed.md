---
name: cuda-backend-feature-required-for-speed
description: "biped_train_gpu MUST be built with --features \"gpu biped_gpu cuda_backend\"; dropping cuda_backend silently halves throughput (2x slower) without erroring."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

When rebuilding `biped_train_gpu` / `biped_render_nexus` for the native-CUDA box, ALWAYS pass
`--features="gpu biped_gpu cuda_backend"`. The example's `required-features` is only `["gpu","biped_gpu"]`
(Cargo.toml line ~90), so a build with just those two SUCCEEDS and RUNS on CUDA — but ~2x slower.

**Why:** `cuda_backend = ["gpu","biped_gpu","khal/cuda","nexus3d/cuda","vortx/cuda"]` (Cargo.toml line 55).
Those `/cuda` sub-features enable the optimized CUDA code paths: `vortx/cuda` = tiled-GEMM PPO update
(the `upd` profile term), `nexus3d/cuda` = fast physics dispatch (the `gpuwait` term). Without cuda_backend
both fall back to generic paths → uniform ~2.5x slowdown across BOTH upd and gpuwait.

**Measured (2026-06-18, v39):** with cuda_backend = 1.3 s/iter (roll 0.78, upd 0.37, pipe 13.5, gpuwait 14.9).
Without = 2.3 s/iter (roll 1.14, upd 0.99, pipe 7, gpuwait 33). Same GPU/cubin/env — purely the feature flag.

**Diagnostics that pin it:** (1) binary size — WITH cuda_backend ~15.68 MB, WITHOUT ~12.87 MB (CUDA code not
compiled in). (2) profile signature flips: pipe DROPS (less host encode) while gpuwait+upd RISE. (3) GPU power
draw stays low (~190 W of 600) = GPU starved between launches. NOT a GPU/clock/CPU-contention issue (clocks
maxed, no throttle, box idle). Cargo keeps prior hashed example binaries under
`target/release/examples/biped_train_gpu-<hash>` — run the older one to A/B confirm timing instantly.

How to apply: every cargo build of these examples uses all three features + the cubin env vars
(CUDA_OXIDE_SHADERS_PTX_NEXUS_RBD_SHADERS3D, CUDA_OXIDE_SHADERS_PTX_VORTX_SHADERS). See [[native-cuda-build-pinning]].

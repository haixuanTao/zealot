---
name: critic-value-sim2sim-gap-detector
description: The trained critic V(s) is a sensitive early scalar detector of the nexus↔MuJoCo sim2sim gap; critic_divergence.py computes it along matched rollouts.
metadata: 
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

User insight (2026-06-23): "if you compute the critic on sim2sim there is clear
divergence." Confirmed and now tooled.

`scripts/critic_divergence.py <nexus_rollout.json> <policy.safetensors>`
runs the SAME policy from the SAME start in nexus (from a biped_render_nexus JSON)
and closed-loop in MuJoCo (reuses sim2sim_xval pieces), and computes the trained
critic V(s) along both. critic_obs(51) = 45 actor-obs + 6 base lin/ang vel
(reconstructed IDENTICALLY for both via finite-diff of the base pose, body frame —
so the V gap is pure state divergence, not method). Loads critic.w_l/b_l +
critic_norm.{mean,m2,count}; ELU stack, linear scalar out; norm = clip((x−mean)/
sqrt(m2/count),±5). Saves a 2-panel plot (V_nexus vs V_mujoco + |ΔV|).

RESULT on v56 (NET + asym DR, final): nexus V mean +7.85 (range 0.6–11.4, walking
on-manifold); MuJoCo V mean −8.12 (range −20.6–6.3). mean |ΔV| = 16.0 = 204% of
|V_nexus|. Divergence onset (|ΔV| > 25%·(|V|+1)) at step 3 ≈ 0.06 s — the critic
flags MuJoCo leaving the nexus manifold ~1 s BEFORE the actual fall (step 56 ≈
1.12 s). So V(s) is a continuous, ~1 s-earlier sim2sim-gap detector than fall time.

INTERPRETATION: the large/immediate divergence says the sim2sim (≈ sim2real) gap
PERSISTS for v56 despite NET symmetry + per-joint asymmetric DR — i.e. the symmetry
work fixed the gait lopsidedness but did NOT close the structural dynamics gap
(consistent with [[foot-slip-sim2real-gap]] / [[nexus-contact-model-realism]]: the
gap is contact/solver fidelity, not reward or symmetry). The critic is privileged +
nexus-trained so some nexus-favoring bias is expected, but ΔV at 204% / onset 60 ms
is far beyond that. Useful as the objective metric to MINIMIZE when chasing transfer.

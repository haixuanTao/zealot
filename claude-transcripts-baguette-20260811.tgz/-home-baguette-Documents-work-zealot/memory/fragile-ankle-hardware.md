---
name: fragile-ankle-hardware
description: The real LeRobot ankle motor is fragile — minimize ankle torque (sim cap 44Nm is ~4-8x the real ~11Nm diamond limit).
metadata: 
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

HARDWARE CONSTRAINT (from the user, 2026-06-15): the real LeRobot bipedal **ankle motor is super
fragile** — training MUST minimize torque on the ankle for sim-to-real safety.

Real ankle limit: coupled motor pair, per-motor firmware tmax=5.5 N·m, achievable set is the diamond
|τ_roll ± τ_pitch| ≤ 11 N·m (NOT a 44×44 box). Source: WBC-AGILE
agile/rl_env/assets/robots/lerobot_humanoid_no_arms.py CoupledAnkleDelayedDCMotorCfg (motor_tmax=5.5).

In zealot the ankle (ankley/anklex) effort_limit is 44 N·m per axis — ~4-8x the real limit — so the sim
lets the policy use far more ankle torque than the hardware survives. The torque penalty weights ankle
heaviest (anklex -6.5e-3, ankley -1.5e-3 vs -5e-4 legs, mirroring WBC) but it's scaled by the 0→0.1x
torque curriculum, so the ankle is only weakly/late protected. NOT sufficient for "avoid ankle torque".

Levers to protect the ankle (see [[native-cuda-build-pinning]] for the torque-penalty plumbing):
- HARD (sim-to-real safe, harder to learn): lower ankle effort_limit in lerobot_bipedal.rs family()
  toward the real ~5.5/axis (pair ≤11), so the sim physically can't exceed deployable ankle torque.
  Risk: robot must balance hip-dominant with tiny ankle torque — may not learn from scratch; ramp the
  cap down as a curriculum.
- SOFT (learnable): keep/raise the ankle torque penalty and DECOUPLE it from the 0.1x curriculum so the
  ankle is penalized at full strength always (BIPED_TORQUE_W scales legs; ankle should stay strong).
- Ideal long-term: implement WBC's coupled-ankle diamond clamp |τ_roll±τ_pitch|≤11 in the nexus motor.
Decision: ankle = SOFT full-strength torque penalty (BIPED_ANKLE_TORQUE_W default 1.0, decoupled from
the 0.1x leg-torque curriculum). Implemented in biped_env_nexus.rs par-compute.

DONE BOTH (2026-06-17, v26). Measured v25's ankle torque (analytic from rollout: τ=clamp(kp·(scale·a−q)−kd·q̇,
±eff)): anklex_left was SUSTAINED ~16.5 N·m, 99% of the time over the 11 N·m limit — the policy held lateral
balance through the ankle roll (lopsided, left leg loaded). Would cook the real motor. FIX (both levers):
(1) HARD cap — lerobot_bipedal.rs family() ankle effort_limit 44 → 15 N·m (both anklex/ankley); this bounds
BOTH the nexus motor saturation (set_motor_max_force) AND the reward torque-clamp. Updated the unit test
(anklex_right effort 44→15). (2) SOFT — launched with BIPED_ANKLE_TORQUE_W=6 (6× the penalty). RESULT: anklex_left
sustained 16.5→4.3 N·m (−74%), 0% over 11 N·m (rare ankley transients to ~12–13, 0.3%, under the 15 cap). And it
stands BETTER (torso 0.713 vs 0.69), still 0/12 limit-riding, still sim2sim-transfers (MuJoCo 6 s, ratio 1.00).
So ankle is now thermally safe AND the policy keeps all the other good properties. TODO if needed: implement the
true coupled diamond clamp |τ_roll±τ_pitch|≤11; tighten cap toward 11–12 once walking is trained. Measurement
script is inline python on the rollout json (kp/kd/effort/scale per family). See [[limit-riding-and-logstd-collapse]], [[nexus-freefall-dynamics-bug]].

ACTUATOR SPEED 2026-06-15: user flagged actuators "too fast" — measured joints peak ~50 rad/s (hipy 52,
hips/ankley/knee 26-34) vs real ~5-15 / WBC cap 32. Root cause: zealot DROPS the MJCF per-joint `damping`
(0.5-2.3 N·m·s/rad) AND `frictionloss` (0.9-1.35), nexus uses a hardcoded 0.1 default damping
(joint_default_damping, multibody.rs:814), and there's no DC-motor torque-speed rolloff. Added real damping
to JointSpec (hipz .514/hipx .738/hipy 1.455/knee 2.264/ankley .029/anklex .214) + parse MJCF `damping`
(MjBody.joint_damping). User chose the quick fix: FOLD damping into the motor kd (no shader change). BUT
measured insufficient for peaks — above ~16 rad/s kd·q̇ braking exceeds the 88 N·m effort clamp, so kd-fold
only damps slow motion. The peaks need the passive damping as a SEPARATE UNCLAMPED drag = nexus's `damping`
buffer (gen_forces -= damping·v), which is host-side seeded (no shader change) but needs from_rapier plumbing
to carry real per-dof damping instead of the 0.1 default. Retraining v5 with the kd-fold to measure a TRAINED
policy's speeds (the replay test used the old undamped policy, unfair); escalate to the damping buffer if
still too fast. frictionloss (Coulomb) not addressed (can't fold into PD kd). v5 → /tmp/biped_policy_v5, train_v5.log.

MJCF DROPPED-PARAM AUDIT 2026-06-15 (user asked "any other param dropped?"): full sweep of MJCF joint/
inertial/geom/option attrs vs zealot's parser. FOUND TWO more drops:
(1) OFF-DIAGONAL INERTIA — MJCF `fullinertia` has 6 vals (Ixx Iyy Izz Ixy Ixz Iyz) but the parser read only
the first 3 (diagonal). Several links have off-diagonals ~50-100% of the diagonal (e.g. Ixy=-0.0082 vs
Ixx=0.0174; another Ixy≈100%), so their inertia tensors are significantly ROTATED and were mis-modelled as
axis-aligned. FIXED host-side (no shader change): parse all 6 into MjBody.inertia_offdiag, build a glam Mat3
(armature added to Izz element), use parry MassProperties::with_inertia_matrix (symmetric_eigen → principal
moments + principal_inertia_local_frame), which nexus's LocalMassProperties.inertia_ref_frame already consumes.
(2) FRICTIONLOSS (Coulomb joint friction, 0.9-1.35 N·m + 0.1 default) — still DROPPED; needs a Coulomb term
(τ=-frictionloss·sign(q̇)), can't fold into the PD/damping; likely a nexus kernel change → deferred.
CONFIRMED OK: armature matches MJCF per-joint; all joint axes "0 0 1" (AngZ holds); COM + mass read.
Launched v6 = most faithful model yet (limits + damping + FULL inertia + ERP + illegal@0.0 + 0.1x torque +
full ankle), 2000 iters → /tmp/biped_policy_v6, train_v6.log. Remaining drop: frictionloss only.

FRICTIONLOSS IMPLEMENTED 2026-06-15 (the kernel-surgery one): added Coulomb joint friction. Confirmed the
explicit `gen_forces-=damping·v` (gravity_and_lu) + implicit `M+=damping·dt` (compute_dynamics_pre) are the
two halves of semi-implicit VISCOUS damping (NOT double-counted), so Coulomb goes ONLY in the explicit term.
Changes: (1) nexus shader gpu_mb_gravity_and_lu — new binding 12 `dof_frictionloss: &[f32]`, apply
`gen_forces -= damping·v + frictionloss·clamp(v/eps,-1,1)` (eps=1 rad/s smooths sign near 0 to avoid chatter,
explicit since Coulomb isn't linear). (2) nexus GpuMultibodySet — `dof_frictionloss` Tensor (dofs_cap×num_batches,
init 0, COPY_DST) + `set_dof_frictionloss(backend, values)` setter + both gravity_and_lu.call() sites pass it.
(3) zealot JointSpec.frictionloss (hipz 1.351/hipx 1.158/hipy 1.312/knee .998/anklex .262/ankley .171, from MJCF)
+ env seeds it env-major [env][dof] via set_dof_frictionloss after from_rapier (root dofs=0; persists across
resets since it's a separate buffer from dof_state). Verified: peak joint vel 52→36 rad/s (hipy 52→19) on the
old policy. ALL MJCF params now applied (range/damping/inertia/frictionloss/armature). v7 = full faithful model,
2000 iters → /tmp/biped_policy_v7, train_v7.log. NOTE kd-fold damping (viscous, effort-clamped) + frictionloss
(Coulomb, unclamped) coexist — different mechanisms, not double-counted. Proper unclamped viscous via the damping
buffer is a further option but kd-fold+frictionloss is functional.
---
name: per-kernel-gpu-profile-and-dispatch-fix
description: "How to profile per-kernel GPU time on the 5090 (nsys too old), the measured kernel ranking, and the dispatch-arg reduction fix (155x, bit-identical)."
metadata: 
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

Profiled the biped native-CUDA step per-kernel at N=8192 to rank the threads(1) kernels (Jun 2026). Key facts:

**Tooling:** nsys 2022.4.2 / ncu on this box are too old for Blackwell (sm_120) — they capture process/thread info but NO CUDA kernel activity (no CUPTI_ACTIVITY_KIND_KERNEL table). Don't waste time on them. Instead use the in-process timer I added: `KHAL_CUDA_PROFILE=1` brackets every launch in khal `cuda.rs::launch()` with sync-before/after, accumulates per-kernel ns in a global, and `khal::backend::cuda::dump_kernel_profile()` (called at end of iter_e2e_bench GPU block, cfg "cuda_backend") prints a sorted table. Serializes the stream so absolute totals are noisy (~100ms run-to-run) but per-kernel ratios are solid. Profiling skips the PPO capture path (sync illegal mid-capture) via a `profiling` guard in the bench.

**Ranking BEFORE fix (% of serialized GPU):** TOP ~50% was THREE threads(1) "dispatch-arg" kernels — `gpu_lbvh_init_dispatch`, `gpu_narrow_phase_init_contacts_dispatch`, `gpu_init_pfm_pfm_dispatch` — each ~3.7ms/call. Root cause: each `threads(1)` kernel SERIALLY scans all `num_batches` (= N = 8192) doing one atomic_load each, in ONE thread, just to compute `max(lens[..])` for the indirect grid. O(N) serial → an anti-scaling term that worsens with N (a real contributor to the throughput plateau). My earlier "threads(1) multibody constraint kernels are THE bottleneck" hypothesis was WRONG by the numbers — see [[cuda-graph-capture-unlock]].

**Fix (DONE, bit-identical, gather err 0.000e0):** converted all 3 to single-workgroup `threads(256)` parallel max-reduction. Shared helper `highest_len_over_batches(lane, num_batches, lens, partial)` in `src_rbd_shaders/broad_phase/lbvh.rs` (grid-stride load + 8-step shared-mem tree reduce, mirrors `side_dot_vel_par` idiom). `pub const DISPATCH_REDUCE_LANES=256` (= WebGPU invocation cap). narrow_phase.rs calls `super::lbvh::highest_len_over_batches`. GOTCHA: `#[spirv(workgroup)]` array types as `SmemBuf<u32,256>` not `[u32;256]` — the helper param must be `&mut impl MaybeIndexUnchecked<u32>` (generic, like the impulse_joint helper), NOT a concrete array. Host `.call(pass, 1u32, ...)` unchanged — block dim derives from `threads()` via the bindgen `#[workgroup_size]`. Result: 3719us -> 24us per call (155x).

**Ranking AFTER fix — the real GPU-compute bottleneck:** `gpu_mb_init_solve_joint_with_bias` (~31%, threads(1), init=LU back-solve + PGS solve per articulation), `gpu_mb_finalize_contact_constraints` (~17%, LU back-solve, threads(1)), `gemm_tiled` (~13%, policy/PPO). These are the multibody per-articulation threads(1) kernels — the cooperative-rewrite target.

**BIG e2e reveal (BIPED_IDLE_DBG=1):** the iter_e2e rollout is NOT GPU-compute-bound in the default (indirect) path — it's HOST-ENCODE-bound: `physics_encode = 1124ms, gpu_wait(compute) = 0` at N=8192. The indirect-dispatch host round-trip (`DispatchGrid::Indirect` does synchronize+clone_dtoh per dispatch) dominates. Only the CAPTURE path (BIPED_CAPTURE=1 BIPED_FIXED_GRID=1) is GPU-compute-bound (`gpu_wait 1055ms`, encode 25ms). So: the dispatch-kernel fix mainly helps GPU compute, which is hidden behind host encode in the indirect path; e2e env/s stayed ~46k @ N=8192/16384 either way. The two highest-ROI levers are now (a) killing the indirect-dispatch host round-trip (or always using fixed-grid/capture), and (b) cooperative rewrite of the multibody threads(1) kernels for the capture path.

**Build reminder:** native-CUDA needs both cubins embedded via PER-CRATE vars (generic `CUDA_OXIDE_SHADERS_PTX` injects ONE cubin into BOTH crates → gemm-not-found): `CUDA_OXIDE_SHADERS_PTX_NEXUS_RBD_SHADERS3D=$HOME/nexus_ptx/nexus_rbd_shaders3d.cubin` and `CUDA_OXIDE_SHADERS_PTX_VORTX_SHADERS=$HOME/nexus_ptx/vortx_shaders.cubin`. Shader edits require rebuilding the cubin: `bash build_cuda/build_nexus_cubin.sh` (cuda-oxide->llvm->ptxas, ~1min, ends with EMBED HASH MATCH OK), then rebuild the host bench with the per-crate vars + `touch crates/nexus_rbd3d/build.rs`.

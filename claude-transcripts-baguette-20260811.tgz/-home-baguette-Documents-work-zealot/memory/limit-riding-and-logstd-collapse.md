---
name: limit-riding-and-logstd-collapse
description: Why every zealot biped policy collapsed to the same pose — limit-riding (unbounded PD targets) + exploration collapse (unclamped GPU log_std). Both fixed.
metadata:
  node_type: memory
  type: project
  originSessionId: 4d615566-fdaa-489f-b55f-d0f13655379e
---

ROOT CAUSE of "every policy does the same movement / training looks broken" (user flagged 2026-06-16).
Diagnosed via the sim2sim harness + checkpoint inspection. The RL loop was NOT dead (weights update, differ
across runs cos 0.68, net responds to obs). TWO structural bugs funneled every run into ONE degenerate attractor:

1. LIMIT-RIDING (unbounded PD targets). `joint_targets = default_pos + action_scale*action` with NO clamp.
   Policy mean actions reached ~2.8; with action_scale this commands targets ~4x past the joint stops (hipx
   target ~1.5 rad vs ±0.349 limit). Result: 70–92% of EVERY joint's time pinned at its limit in both v7 & v8
   → identical contorted pose → identical topple. PD slams the stop at near-saturated torque every step (wastes
   torque, esp. the FRAGILE ANKLE) and the beyond-limit region is flat/zero-gradient so the policy gets stuck.
   FIX: clamp the target to the joint limit in VelocityFlatTask::joint_targets (velocity_flat.rs) —
   `(default_pos + action_scale*action).clamp(lo,hi)` using j.pos_limit. NOTE: do NOT clamp the ACTION to
   ±1 — scales are NOT calibrated to limit at |a|=1 (hipy needs |a|≈2.85 to reach its ±1.047 limit, hipx only
   ≈0.63), so an action clamp would cripple hip-pitch flexion. Clamp the TARGET, per-joint. (Caveat: pos_limit
   is the symmetric family default; the env's actual MJCF range can be asymmetric — minor residual on one side.)

2. EXPLORATION COLLAPSE (unclamped GPU log_std). biped_train_gpu.rs trains log_std on the GPU "al" Adam pass
   (lst tensor), which has NO floor — the -1.6 clamp in ppo.rs::step_log_std is DEAD CODE (that host path isn't
   used). log_std sank to ~-2.77 (std 0.06, init was 1.0) → policy stopped exploring and locked into the bad
   pose early. FIX: after reading lst back into ac.log_std each iter, clamp to [-1.6, 0.0] (std 0.2–1.0) and
   write the clamped values back into the lst GPU buffer (rebuild via mk()) so the next update continues floored.

DEEPER (not a bug, a difficulty): nexus is ~5x less stable than MuJoCo (sim2sim gap) — zero pose passively
holds ~1.5s in MuJoCo vs ~0.2s in nexus, so episodes die in ~10 steps, too fast to learn balance from the
unstable all-zeros spawn. NOTE the all-zeros spawn/default pose is straight-legged (torso 0.72 > 0.62 target)
and only marginally stable; WBC-AGILE ALSO uses all-zeros joint_pos but spawns with a ~-10° pitch
counter-rotation for ITS url-frame tilt (zealot's identity spawn is correct for ~/tmp_eval/mjcf/robot.xml —
identity held longest of the options tested) and trains in stable Isaac with far more samples.

RESIDUAL LIMIT-RIDING + FIX (2026-06-17, v25). Even after the target-clamp + motor fix, the standing policy
still rode the LATERAL HIP limits (hipx roll + hipz yaw both pinned at 100% of their ±0.349 / ±20° range, 5/12
joints >90% — same as v17). It splays the legs into a wide "sumo" brace for lateral balance on the narrow box
feet, and the existing dof_pos_limits penalty (soft band at 0.9·limit, weight -0.5) was far too weak to deter it
(only -0.0016/step even when pinned). FIX: repurposed the unused `pose` reward weight (was 0, WBC port dropped
the full-posture term) into an ALWAYS-ON L2 deviation penalty on hipz+hipx only (self.hip_yawroll_idx) —
velocity_flat.rs reward(): `pose = weights.pose * Σ_hipyawroll (q-default)² * dt`. Tuning: weight -2.0 did
NOTHING (interior optimum still at the limit); -8.0 WORKED → hipx/hipz drop to ~30-40% mean / ~60% max, 0/12
joints >90%, still stands (falls ~7), and STILL sim2sim-transfers (MuJoCo full 6s survival, ratio 1.00 — the
anti-brace did not hurt transfer; drift 3cm→34cm = active balance vs rigid lock, expected/healthier). Targets
ONLY hipz/hipx so the sagittal walking DOFs (hipy/knee/ankley) stay free. CAVEAT: always-on, so it will resist
hipz during YAW-rate commands when walking — gate it down / exempt hipz under a yaw command then. User's
complementary idea (also lower the dof_pos_limits soft factor 0.9→~0.8 so the penalty engages earlier for ALL
joints, not just the hips) is a good general backstop, not yet applied (the hip penalty alone cleared it).

v9 = first run with BOTH fixes, DEFAULT reward weights, 2000 iters → /tmp/biped_policy_v9.safetensors.
OUTCOME (decisive, 2026-06-16): both fixes CONFIRMED WORKING — exploration std 0.06→0.45+, limit-riding
69%→57% mean joint-pinning (hip pinning ~halved). But in NEXUS v9 still falls every ~8 steps (0.16s), worse
training falls (~9000). The decisive test was running the SAME v9 policy through the sim2sim harness:
  nexus: 0.16s   |   MuJoCo: 1.60s + 78cm forward (~0.49 m/s vs 0.4 commanded) — a 10x gap.
In proper MuJoCo physics v9 HOLDS height (~0.72) and STRIDES FORWARD — it's the best policy yet and is
starting to walk. The policy is fine; NEXUS INSTABILITY IS THE WALL. The robot can't stay up in nexus long
enough (10 steps) for the learned behavior to show, but the same weights semi-walk in MuJoCo. Progression of
MuJoCo survival across fixes: v7 1.28s/64cm, v8 0.98s, v9 1.60s/78cm (fixes helped). CONCLUSION: stop policy/
reward tuning — the next move is to FIX NEXUS STABILITY (the sim2sim harness quantifies it at 5–10x and can
drive a passive nexus-vs-MuJoCo dynamics comparison to localize the bug) or train in a stable engine. See
[[sim2sim-policy-crossval]], [[fragile-ankle-hardware]], [[prefers-natural-motion]], [[nexus-freefall-dynamics-bug]].
